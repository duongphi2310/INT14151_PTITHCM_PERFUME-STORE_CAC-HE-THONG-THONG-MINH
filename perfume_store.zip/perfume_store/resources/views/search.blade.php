<!DOCTYPE html>
<html>
<head>
    <title>Tìm kiếm thông tin</title>
</head>
<body>
    <form method="POST" action="{{ route('search') }}">
        @csrf
        <label for="keyword">Nhập từ khóa:</label>
        <input type="text" name="keyword" id="keyword" required>
        <button type="submit">TÌM</button>
    </form>
    @isset($searchResult)
    <h2>Kết quả tìm kiếm:</h2>
    <p>{{ $searchResult }}</p>
    @endisset
</body>
</html>
