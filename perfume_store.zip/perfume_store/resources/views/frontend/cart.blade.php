@extends('frontend.layout.master')

@section('content')
    
    <!-- Cart Start -->
    
    <div class="container-fluid pt-5">

        @if (session('success'))
            <div class="alert alert-success">
                {{session('success')}}
            </div>
        @endif
        
        @if(session('cart'))
        <div class="row px-xl-5">
            <div class="col-lg-8 table-responsive mb-5">
                <table class="table table-bordered text-center mb-0">
                    <thead class="bg-secondary text-dark">
                        <tr>
                            <th>TÊN SẢN PHẨM</th>
                            <th>ĐƠN GIÁ</th>
                            <th>THỂ TÍCH</th>
                            <th>SỐ LƯỢNG</th>
                            <th>TỔNG TIỀN</th>
                            <th>XÓA</th>
                        </tr>
                    </thead>
                    <tbody class="align-middle">
                        
                        @foreach (session('cart') as $cart )
                            <tr>
                                <td class="align-middle"><img src="{{$cart['image']}}" style="width: 55px; padding-right:5px">
                                    <a href="{{route('product', $cart['product_id'])}}">{{$cart['name']}}</a>
                                </td>
                                <td class="align-middle">{{number_format($cart['price'])}}đ</td>
                                <td class="align-middle">{{$cart['size']}}</td>
                                <td class="align-middle">
                                    <div class="input-group quantity mx-auto" style="width: 100px;">
                                        <input readonly class="form-control form-control-sm bg-secondary text-center" value="{{$cart['quantity']}}" disabled>
                                    </div>
                                </td>
                                <td class="align-middle">{{number_format($cart['quantity'] * $cart['price'])}}đ</td>
                                <form method="POST" action="{{route('cart.delete', [$cart['product_id'], $cart['size']])}}">
                                    @method('DELETE')
                                    @csrf
                                    <td class="align-middle">
                                        <button type="submit" class="btn btn-sm btn-primary">
                                            <i class="fa fa-times"></i>
                                        </button>
                                    </td>
                                </form>
                            </tr> 
                        @endforeach
                                             
                    </tbody>
                </table>
                
            </div>
            <div class="col-lg-4">
                <div class="card border-secondary mb-5">
                    <div class="card-header bg-secondary border-0">
                        <h4 class="font-weight-semi-bold m-0">CHI TIẾT THANH TOÁN</h4>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-3 pt-1">
                            <h6 class="font-weight-medium">TỔNG TIỀN HÀNG</h6>
                            <h6 class="font-weight-medium">{{number_format(session('total_price'))}}đ</h6>
                        </div>
                        <div class="d-flex justify-content-between">
                            <h6 class="font-weight-medium">PHÍ VẬN CHUYỂN</h6>
                            <h6 class="font-weight-medium">MIỄN PHÍ</h6>
                        </div>
                    </div>
                    <div class="card-footer border-secondary bg-transparent">
                        <div class="d-flex justify-content-between mt-2">
                            <h5 class="font-weight-bold">THÀNH TIỀN</h5>
                            <h5 class="font-weight-bold">{{ number_format(session('total_price')) }}đ</h5>
                        </div>
                        <a href="{{ route('checkout') }}" class="btn btn-block btn-primary my-3 py-3">
                            MUA HÀNG ({{ session('cart') ? count(session('cart')) : 0 }})
                        </a>
                    </div>

                </div>
            </div>
        </div>
        @else
            <h5 class="text-center">Không có sản phẩm nào!</h5>
            <div class="row justify-content-center">
                <a href="{{route('shop')}}" class="btn btn-primary my-4">Continue shopping</a>
            </div>
        @endif 
    </div>
    <!-- Cart End -->

@endsection
