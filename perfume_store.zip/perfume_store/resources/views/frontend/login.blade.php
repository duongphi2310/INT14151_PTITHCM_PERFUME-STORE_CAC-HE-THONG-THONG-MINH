@extends('frontend.layout.master')

@section('content')

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

<style>

#login .container #login-row #login-column #login-box {
  max-width: 600px;
  height: 320px;
  border: 1px solid #d7d7d7;
}
#login .container #login-row #login-column #login-box #login-form {
  padding: 20px;
}
#login .container #login-row #login-column #login-box #login-form #register-link {
  margin-top: -45px;
}
</style>

<div id="login">
    <div class="container">
        <div id="login-row" class="row justify-content-center align-items-center">
            <div id="login-column" class="col-md-6">
                @if (session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif
                <div id="login-box" class="col-md-12 shadow-none p-3 mb-5 bg-light rounded">
                    <form id="login-form" class="form" action="{{route('loginPost')}}" method="post">
                        @csrf
                        <h3 class="text-center text-primary">> ĐĂNG NHẬP <</h3>
                        <div class="form-group">
                        <input type="text" name="email" id="email" class="form-control" placeholder="Email" style="margin-top: 30px;" />
                            @error('email')
                                <p class="text-danger">{{$message}}</p>
                            @enderror
                        </div>
                        <div class="form-group">

                        <div class="password-container">
                            <input type="password" name="password" id="password" class="form-control" placeholder="Mật khẩu" style="margin-top: 20px; margin-bottom: 20px; padding-right: 40px;" />
                            <button type="button" id="togglePassword" class="password-toggle-button">
                                <!-- Icon for an eye from Font Awesome -->
                                <i class="fas fa-eye password-icon"></i>
                            </button>
                        </div>

                        <script>
                            const passwordField = document.getElementById('password');
                            const togglePasswordButton = document.getElementById('togglePassword');

                            // Sự kiện click trên nút ẩn/hiện
                            togglePasswordButton.addEventListener('click', function () {
                                if (passwordField.type === 'password') {
                                    passwordField.type = 'text';
                                    togglePasswordButton.innerHTML = '<i class="fas fa-eye-slash password-icon"></i>';
                                } else {
                                    passwordField.type = 'password';
                                    togglePasswordButton.innerHTML = '<i class="fas fa-eye password-icon"></i>';
                                }
                            });
                        </script>
                            
                            @error('password')
                                <p class="text-danger">{{$message}}</p>
                            @enderror
                        </div>
                        <div class="form-group">
                            <button type="submit"class="btn btn-primary btn-md" >
                                ĐĂNG NHẬP
                            </button>
                        </div>
                        <div id="register-link" class="text-right">
                            <a href="{{route('register')}}" class="text-primary">ĐĂNG KÝ</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection