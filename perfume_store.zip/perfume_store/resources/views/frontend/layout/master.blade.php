<!DOCTYPE html> <html lang="en"> <head> <meta charset="utf-8" /> <title>N3 PERFUME</title> <meta
    content="width=device-width, initial-scale=1.0" name="viewport" /> <meta content="Free HTML Templates"
    name="keywords" />
<meta content="Free HTML Templates" name="description" /> <!-- Favicon --> <link href="/assets/frontend/img/favicon.ico"
    rel="icon" /> <!-- Google Web Fonts --> <link rel="preconnect" href="https://fonts.gstatic.com" /> <link
    href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
    rel="stylesheet" /> <!-- Font Awesome -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet" /> <!--
    Libraries Stylesheet --> <link href="/assets/frontend/lib/owlcarousel/assets/owl.carousel.min.css"
    rel="stylesheet" /> <!-- Customized Bootstrap
    Stylesheet --> <link href="/assets/frontend/css/style.css" rel="stylesheet" />
</head> 
<body> 
<!-- Topbar Start --> 
<div class="row align-items-center py-3 px-xl-5">
    <div class="col-lg-3 d-none d-lg-block"> 
        <a href="" class="text-decoration-none"> 
            <h1 class="m-0 display-5 font-weight-semi-bold"> 
                <span class="text-primary font-weight-bold border px-3 mr-1">N3</span> PERFUME 
            </h1>
        </a> 
    </div> 
    <div class="col-lg-6 col-6 text-left">
        <form action="{{route('shop')}}" method="get"> 
            <div class="input-group"> <input type="text" name="search" class="form-control" placeholder="Tìm kiếm sản phẩm, thương hiệu ..." />
                <div class="input-group-append"> 
                    <button type="submit" class="input-group-text bg-transparent text-primary"> 
                        <i class="fa fa-search"></i> 
                    </button>
                </div>
            </div>
        </form>
    </div>
    <!-- frontend.cart.blade.php -->
    <div class="col-lg-3 col-6 text-right"> 
    <form method="POST" action="{{ route('search') }}"> 
    @csrf
    <div style="display: flex; align-items: center;">
        <input type="text" name="keyword" id="keyword" placeholder="TÌM KIẾM THÔNG MINH ..." required style="margin-right: 10px;">
        <button type="submit">TÌM</button>
    </div>
</form>


    </div> 
    <style>
        /* CSS để căn giữa form */
        .centered-form {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 50vh;
        }

        /* CSS cho form */
        form {
            background-color: #f5f5f5;
            padding: 5px;
            border: 1px solid #ddd;
            border-radius: 5px;
            text-align: center;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"] {
            width: 100%;
            padding: 5px;
            margin-bottom: 5px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        button {
            padding: 5px 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        #cancelButton {
            margin-right: 5px;
            background-color: #ccc;
        }
    </style>

</div>

        
<!-- Topbar End -->

<!-- Navbar Start -->
<div class="container-fluid mb-5">
    <div class="row border-top px-xl-5">
    <div class="col-lg-9">
    <nav class="navbar navbar-expand-lg bg-light navbar-light py-3 py-lg-0 px-0">
        <a href="" class="text-decoration-none d-block d-lg-none">
        <h1 class="m-0 display-5 font-weight-semi-bold"><span
        class="text-primary font-weight-bold border px-3 mr-1">N3</span>PERFUME</h1>
        </a>
        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
            <div class="navbar-nav mr-auto py-0">
                <a href="{{route('home')}}" class="nav-item nav-link">TRANG CHỦ</a>
                <span class="nav-divider">|</span>
                <a href="{{route('shop')}}" class="nav-item nav-link">CỬA HÀNG</a>
                <span class="nav-divider">|</span>
                @foreach ($categories as $category)
                <a href="{{route('category', $category->id)}}" class="nav-item nav-link">{{$category->name}}</a>
                <span class="nav-divider">|</span>
                @endforeach
            </div>
            <div class="navbar-nav ml-auto py-0">
                @if (Auth::guard('web')->check())
                <div class="d-flex">
                    <p class="mt-2 text-dark font-weight-bold">{{Auth::guard('web')->user()->name}}</->
                    <form action="{{route('logout')}}" method="POST">
                        @csrf
                        <button class="btn">ĐĂNG XUẤT</button>
                    </form>
                </div>
                @else
                <a href="{{route('login')}}" class="nav-item nav-link">ĐĂNG NHẬP</a>
                <span class="nav-divider">|</span>
                <a href="{{route('register')}}" class="nav-item nav-link">ĐĂNG KÝ</a>
                @endif
            </div>
            <div class="col-lg-3 col-6 text-right"> 
                <a href="{{ route('cart') }}" class="btn border"> 
                    <i class="fas fa-shopping-cart text-primary">
                    <span class="item-count @if(session('cart')) text-danger @endif">
                    @if(session('cart'))
                    {{ count(session('cart')) }}
                    @else
                    0
                    @endif
                    </span>
                </i>
                </a>
        <a href="{{ Auth::check() ? route('frontend.listorders') : route('login') }}" class="btn border">
            <i class="fas fa-clipboard-list text-primary"></i>
            <span> ĐƠN HÀNG</span>
        </a>
        </div>
    </nav>
</div>
</div>
</div>
<!-- Navbar End -->

@yield('content')

<!-- Footer Start -->
<div class="row px-xl-5 pt-5">
    <div class="col-lg-4 col-md-12 mb-5 pr-3 pr-xl-5">
        <a href="" class="text-decoration-none">
            <h1 class="mb-4 display-5 font-weight-semi-bold">
                <span class="text-primary font-weight-bold border border-white px-3 mr-1">N3</span>PERFUME
            </h1>
        </a>
        <p>
            Ra đời vào ngày 20/09/2023 và hiện tại là nơi cung cấp hơn 20
            nhãn hiệu nước hoa cao cấp trên thế giới. Định hướng của chúng
            tôi là trở thành nhà cung cấp nước hoa phổ biến, mang lại sự
            lựa chọn đa dạng, sự thuận tiện, tiết kiệm tiền & thời gian,
            đồng thời mang đến sự yên tâm & hài lòng đến với khách hàng.
        </p>
        <p class="mb-2">
            <i class="fa fa-map-marker-alt text-primary mr-3"></i>97 Đường Man Thiện, Phường Hiệp Phú, TP. Thủ
            Đức,
            TP. Hồ Chí Minh
        </p>
        <p class="mb-2">
            <i class="fa fa-envelope text-primary mr-3"></i>phisuper2310@gmail.com
        </p>
        <p class="mb-0">
            <i class="fa fa-phone-alt text-primary mr-3"></i>+ (84) 988 919 701
        </p>
    </div>
    <div class="col-lg-8 col-md-12">
        <div class="row">
            <div class="col-md-4 mb-5">
                <h5 class="font-weight-bold text-dark mb-4">
                    LIÊN KẾT
                </h5>
                <div class="d-flex flex-column justify-content-start">
                    <a class="text-dark mb-2" href="{{route('home')}}"><i class="fa fa-angle-right mr-2"></i>TRANG
                        CHỦ</a>
                    <a class="text-dark mb-2" href="{{route('shop')}}"><i class="fa fa-angle-right mr-2"></i>CỬA
                        HÀNG</a>
                    <a class="text-dark mb-2" href="detail.html"><i class="fa fa-angle-right mr-2"></i>Shop
                        Detail</a>
                    <a class="text-dark mb-2" href="cart.html"><i class="fa fa-angle-right mr-2"></i>Shopping
                        Cart</a>
                    <a class="text-dark mb-2" href="checkout.html"><i class="fa fa-angle-right mr-2"></i>Checkout</a>
                    <a class="text-dark" href="contact.html"><i class="fa fa-angle-right mr-2"></i>Contact
                        Us</a>
                </div>
            </div>

        </div>
    </div>
    <div class="row border-top border-light mx-xl-5 py-4">
        <div class="col-md-6 px-xl-0">
            <p class="mb-md-0 text-center text-md-left text-dark">
                <a class="text-dark font-weight-semi-bold" style="white-space: nowrap;">NHÓM 3</a>
            </p>
        </div>
    </div>

</div>
<!-- Footer End -->

<!-- Back to Top -->
<a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>

<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
<script src="/assets/frontend/lib/easing/easing.min.js"></script>
<script src="/assets/frontend/lib/owlcarousel/owl.carousel.min.js"></script>

<!-- Contact Javascript File -->
<script src="/assets/frontend/mail/jqBootstrapValidation.min.js"></script>
<script src="/assets/frontend/mail/contact.js"></script>

<!-- Template Javascript -->
<script src="/assets/frontend/js/main.js"></script>
</body>

</html>