//Khi click #thumbnail thì cũng gọi sự kiện click #image

// Ajax setup
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

$(document).ready(function () {
    $('.thumbnail').click(function () {
        $(this).siblings('.image').click();
    });

    $("#addImageButton").click(function() {
        var imageInput = $("<input>", {
            type: "file",
            class: "image-input",
            name: "images[]",
            accept: "image/png, image/gif, image/jpeg"
        });

        var previewImage = $("<img>", {
            class: "preview-image",
            width: 100,
            src: ''
        });

        var imageDiv = $("<div>", {
            class: "image-container mt-2",
            html: [imageInput, previewImage]
        });

        $("#imageContainer").append(imageDiv);
        
        imageInput.change(function() {
            var file = this.files[0];
            if (file) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    previewImage.attr("src", e.target.result);
                };
                reader.readAsDataURL(file);
            }
        });
    });



});

function previewImg(input, id) {
    var file = input.files[0];
    if (file) {
        var reader = new FileReader();
        reader.onload = function(e) {
            $(".preview-image-" + id).attr("src", e.target.result);
        };
        reader.readAsDataURL(file);
    }
    
}

$(document).on("click", ".deleteButton", function() {
    $(this).closest(".input-section").remove();
});
