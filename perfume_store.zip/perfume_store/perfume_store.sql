-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for perfume_shop
CREATE DATABASE IF NOT EXISTS `perfume_shop` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `perfume_shop`;

-- Dumping structure for table perfume_shop.admins
CREATE TABLE IF NOT EXISTS `admins` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table perfume_shop.admins: ~3 rows (approximately)
INSERT INTO `admins` (`id`, `name`, `email`, `password`, `created_at`, `updated_at`) VALUES
	(2, 'Admin', 'admin@yomail.com', '$2y$10$DG9wUnZ4XL1oLlrl8rbCoekRsRSg3O79LZUzcrzgb3PEsL4DOHypu', '2023-09-30 05:51:26', '2023-09-30 05:51:26'),
	(3, 'Vũ Quang', 'test@test.com', '$2y$10$pPqbwuVzRNhBPQFrXa3aOOvm3yB1fnbL25mFAh6R1619PcZqpK0..', '2023-09-30 05:51:26', '2023-09-30 05:51:26');

-- Dumping structure for table perfume_shop.brands
CREATE TABLE IF NOT EXISTS `brands` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `brands_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table perfume_shop.brands: ~6 rows (approximately)
INSERT INTO `brands` (`id`, `name`, `created_at`, `updated_at`) VALUES
	(6, 'VERSACE', '2023-09-28 23:19:47', '2023-09-28 23:19:47'),
	(7, 'DIOR', '2023-09-28 23:19:56', '2023-09-28 23:19:56'),
	(8, 'CHANEL', '2023-09-28 23:21:02', '2023-09-28 23:21:02'),
	(9, 'GUCCI', '2023-09-28 23:21:17', '2023-09-28 23:21:17'),
	(10, 'BURBERY', '2023-09-28 23:21:39', '2023-09-28 23:21:39'),
	(11, 'YSL', '2023-09-28 23:25:08', '2023-09-28 23:25:08'),
	(12, 'TOM FORD', '2023-09-28 23:25:23', '2023-09-28 23:25:23');

-- Dumping structure for table perfume_shop.categories
CREATE TABLE IF NOT EXISTS `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table perfume_shop.categories: ~3 rows (approximately)
INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
	(1, 'NƯỚC HOA NAM', '2023-09-07 21:41:20', '2023-09-07 21:42:25'),
	(2, 'NƯỚC HOA NỮ', '2023-09-07 21:41:28', '2023-09-07 21:42:32'),
	(3, 'NƯỚC HOA UNISEX', '2023-09-07 21:55:18', '2023-09-07 21:55:18');

-- Dumping structure for table perfume_shop.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table perfume_shop.migrations: ~12 rows (approximately)
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_10_12_000000_create_users_table', 1),
	(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
	(3, '2019_08_19_000000_create_failed_jobs_table', 1),
	(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
	(5, '2023_08_16_180835_create_brands_table', 1),
	(6, '2023_08_17_095151_create_categories_table', 1),
	(7, '2023_08_17_180043_create_products_table', 1),
	(8, '2023_08_17_180057_create_product_items_table', 1),
	(9, '2023_08_17_180105_create_product_images_table', 1),
	(10, '2023_08_20_054439_create_admins_table', 1),
	(11, '2023_08_20_083510_create_orders_table', 1),
	(12, '2023_08_20_083928_create_order_product_table', 1);

-- Dumping structure for table perfume_shop.orders
CREATE TABLE IF NOT EXISTS `orders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_price` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_user_id_foreign` (`user_id`),
  CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table perfume_shop.orders: ~2 rows (approximately)
INSERT INTO `orders` (`id`, `user_id`, `name`, `email`, `phone`, `address`, `total_price`, `created_at`, `updated_at`) VALUES
	(6, 6, 'Duong Phi', 'test1@gmail.com', '1212121212', '12121212', 4300000, '2023-09-30 06:51:46', '2023-09-30 06:51:46'),
	(7, 6, 'Duong Phi', 'test1@gmail.com', '1212121212', '12121212s', 2900000, '2023-09-30 07:26:11', '2023-09-30 07:26:11'),
	(8, 6, 'Duong Phi Nguyen', 'n20dccn125@student.ptithcm.edu.vn', '0988919701', '97 Man Thien, Phuong Hiep Phu', 5470000, '2023-10-01 02:07:45', '2023-10-01 02:07:45'),
	(9, 6, 'Duong Phi Nguyen', 'n20dccn125@student.ptithcm.edu.vn', '0988919701', '97 Man Thien, Phuong Hiep Phu', 2900000, '2023-10-01 03:16:06', '2023-10-01 03:16:06'),
	(10, 7, 'quang vu', 'vuquang@gmail.com', '0123456789', 'hjhj', 5570000, '2023-10-03 23:28:13', '2023-10-03 23:28:13');

-- Dumping structure for table perfume_shop.order_product
CREATE TABLE IF NOT EXISTS `order_product` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `quantity` int NOT NULL,
  `size` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_product_order_id_foreign` (`order_id`),
  CONSTRAINT `order_product_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table perfume_shop.order_product: ~7 rows (approximately)
INSERT INTO `order_product` (`id`, `order_id`, `product_id`, `quantity`, `size`, `price`, `created_at`, `updated_at`) VALUES
	(9, 6, 20, 1, '75', 4300000, NULL, NULL),
	(10, 7, 25, 1, '100', 2900000, NULL, NULL),
	(11, 8, 26, 1, '90', 2570000, NULL, NULL),
	(12, 8, 25, 1, '100', 2900000, NULL, NULL),
	(13, 9, 25, 1, '100', 2900000, NULL, NULL),
	(14, 10, 27, 1, '100', 3000000, NULL, NULL),
	(15, 10, 26, 1, '90', 2570000, NULL, NULL);

-- Dumping structure for table perfume_shop.password_reset_tokens
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table perfume_shop.password_reset_tokens: ~0 rows (approximately)

-- Dumping structure for table perfume_shop.personal_access_tokens
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table perfume_shop.personal_access_tokens: ~0 rows (approximately)

-- Dumping structure for table perfume_shop.products
CREATE TABLE IF NOT EXISTS `products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `brand_id` bigint unsigned NOT NULL,
  `category_id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double NOT NULL,
  `style` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `featured` tinyint NOT NULL DEFAULT '0',
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_name_unique` (`name`),
  KEY `products_brand_id_foreign` (`brand_id`),
  KEY `products_category_id_foreign` (`category_id`),
  CONSTRAINT `products_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table perfume_shop.products: ~14 rows (approximately)
INSERT INTO `products` (`id`, `brand_id`, `category_id`, `name`, `price`, `style`, `product_code`, `featured`, `description`, `created_at`, `updated_at`) VALUES
	(13, 6, 1, 'VERSACE Eros Man EDT', 1480000, 'Mạnh mẽ, nam tính, cổ điển', 'H000454', 1, '<p>Nước Hoa Nam Versace Eros Man EDT 100ml là nguồn cảm hứng từ vị thần tình yêu trong thần thoại Hy Lạp.</p><p>Là biểu tượng cho thần tình yêu Hy Lạp, đại diện của tình yêu, là trung tâm của các hương thơm, là sự kết hợp và thể hiện của niềm đam mê vô tận và ham muốn mãnh liệt.</p>', '2023-09-28 23:41:34', '2023-09-28 23:42:58'),
	(14, 7, 1, 'Christian Dior Sauvage EDP', 2750000, 'Mạnh mẽ, trẻ trung, hiện đại', 'H000461', 1, '<p>Nước hoa Dior Sauvage EDP 100ml là chai nước hoa nam mớ<a href="https://vuahanghieu.com/nuoc-hoa/nam">i</a> mang phương vị đậm chất Phương Đông, hương vị vani đầy ấm áp, gợi cảm và rất tinh tế.&nbsp;Mùi hương Dior Sauvage EDP&nbsp;được ví von như một bản giao hưởng hiện đại với những cung bậc cảm xúc nồng nhiệt khác nhau qua các tầng hương.</p>', '2023-09-29 00:06:26', '2023-09-29 18:05:16'),
	(15, 6, 2, 'Versace Bright Crystal EDT', 1490000, 'Thơm mát, dịu ngọt', 'H003818', 1, '<p><strong>Nước hoa Versace Bright Crystal 90ml</strong> là mẫu nước hoa nữ cá tính, một món quà tuyệt vời và tinh tế vì hương thơm tươi mát, sảng khoái, có chút cổ điển pha lẫn bí ẩn mà chính bạn có thể “tự thưởng” cho bản thân mình.</p><p>Lấy cảm hứng từ những sáng tạo độc đáo của hương nước hoa dòng Donatella Versace, chuyên gia nước hoa <strong>Alberto Morillas</strong> đã vẽ nên một viên kim cương lấp lánh cho những buổi dạ tiệc lãng mạn để làm nên những câu chuyện tình đầy thăng hoa.</p><p>Ra mắt vào 2006, <strong>Bright Crystal </strong>sở hữu hương thơm ngọt ngào quyến rũ phân tầng, khi mát dịu của lựu, yuzu cùng mùi hương đầy lãng mạn và gợi tình của mẫu đơn, mộc lan, lúc lại hòa quyện cùng hương thơm ấm áp của xạ hương. Các tầng hương cứ quyện tròn, xoáy trào lên nhau và tạo nên những khúc ca thanh xuân tươi đẹp.</p><p>Được thiết kế với tông màu hồng nhạt rất đẹp dễ và gợi cảm, thể hiện đặc trưng của dòng sản phẩm dành cho phái nữ. Mọi chi tiết của nước hoa Versace Bright Crysta<a href="https://vuahanghieu.com/versace/nuoc-hoa/versace-bright-crystal">l</a> được gia công rất tinh tế và đẳng cấp, làm tăng lên vẻ đẹp thẩm mỹ bên ngoài như một viên kim cương đầy mê hoặc làm nổi bật được đẳng cấp của người sử dụng <strong>chai Versace Bright Crystal 90ml</strong> này.</p><p>Sự bố trí hài hòa, ấm áp có phần hơi "khô thoáng" ở các tầng hương nước hoa, tất cả thành phần không có sự áp đảo mà ngược lại đem cho chúng ta một hương vị rất dễ chịu. Hương hoa cỏ trái cây làm bật lên vẻ đẹp nữ tính, sự năng động và gần gũi của hương vị đặc trưng của phái nữ.</p><p>&nbsp;</p>', '2023-09-29 17:59:23', '2023-09-29 17:59:23'),
	(16, 10, 2, 'Burberry Brit Sheer For Her EDT', 1190000, 'Trẻ trung, dịu dàng, nữ tính', 'H081074', 1, '<p><strong>Nước Hoa Nữ Burberry Brit For Her EDT 100ml&nbsp;</strong>tràn ngập bởi những cánh đồng hoa trải dài như vô tận hay những đồng cỏ xanh tươi mát để bạn luôn thỏa mình và chìm đắm với những hương hoa cỏ tự nhiên từ trái cây Floral Fruity. Các cô nàng Burberry Brit Sheer hút hồn các chàng trai với hương thơm gọi mời, gợi cảm khó quên.</p><p><strong>Nước Hoa Nữ Burberry Brit Sheer For Her EDT 100ml</strong> ra mắt năm 2015, được giới thiệu như một phiên bản thanh lịch và nữ tính hơn so với dòng sản phẩm cùng tên vào năm 2007. Mùi hương ngọt ngào, ngập tràn hương vị đam mê của “nàng thơ” này sẽ khiến dấu ấn của bạn trở nên đặc biệt hơn bao giờ.</p><p>Nước hoa <strong>Burberry Brit Sheer</strong> có thiết kế dạng chai thủy tinh cổ điển với tông hồng pastel là nguồn cảm hứng chủ đạo. Thân chai được trang trí tỉ mỉ bằng họa tiết kẻ sọc caro đình đám của thương hiệu Burberry. Đơn giản, trang nhã và ấn tượng trong từng chuyển động, nước hoa <strong>Burberry Brit Sheer EDT</strong> chắc hẳn sẽ là item&nbsp;tuyệt vời để bổ sung vào BST Burberry’s perfume của bạn.</p><p><strong>Nước Hoa Nữ Burberry Brit Sheer For Her EDT m</strong>ở đầu “bản hòa nhạc” là vẻ mọng nước của Quả vải, đi đôi với sự thanh mát của Cam Quýt cùng Quả Yuzu để tạo nên tầng hương đầu thơm ngọt và không quá nồng. Càng đi sâu vào “bản nhạc”, Brit Sheer mới dần hé lộ những yếu tố điển hình cấu thành nên sự độc đáo của mình. Ngọt đến say của Hoa đào, sảng khoái của Lê, nữ tính của Mẫu đơn hồng. Tất cả như vẽ nên chân dung người phụ nữ hiện đại cùng nét phóng khoáng, thoải mái nhưng vẫn giữ cho mình sự dịu dàng vốn có.</p><p>Để Brit Sheer có thể là phiên bản hoàn hảo, nhà chế tác đã tinh tế “kích thích” khứu giác với Xạ hương trắng mềm mại và Gỗ trắng ấm áp đến nhẹ nhàng. Hẳn Brit Sheer là một lời mời gọi khó từ chối đối với bất kỳ ai. <strong>Nước hoa Burberry Brit Sheer</strong> là loại có nồng EDT với hàm lượng tinh dầu trung bình, hương thơm nhẹ nhàng và khá bền mùi. <strong>Burberry Brit Sheer Eau De Toilette</strong> thuộc dòng nước hoa nữ, đặc biệt phù hợp để sử dụng vào ban ngày, trong thời tiết mát mẻ của mùa xuân – hạ.</p>', '2023-09-29 18:40:27', '2023-09-29 18:40:27'),
	(17, 6, 2, 'Versace Pour Femme Dylan Turquoise EDT', 1600000, 'Nữ tính, thanh lịch, tinh tế', 'H030114', 1, '<p><strong>Dylan Turquoise</strong> là một hương thơm mới cho nữ giới của thương hiệu Versace. Mùi hương là sự kết hợp giữa truyền thống và hiện đại, tạo cho ta cảm giác như được chạy trốn đến những hòn đảo xa xôi với trời xanh và làn nước trong vắt lấp lánh.</p><p>Một trong những bộ cánh mới đến từ nhà Versace vào mùa thu năm 2020, Pour Femme Dylan Turquoise sở hữu một thiết kế vô cùng độc đáo từ vẻ ngoài cho đến bên trong khiến cho chai nước hoa này dần trở nên phổ biến đến giới hâm mộ ngày một nhiều hơn.<br>Thiết kế chai là một biểu hiện của thiết kế sáng tạo, đường cong thanh lịch của nó mang đến cảm giác như một chiếc bình amphora của văn hóa Hy Lạp và thần thoại. Thân chai phủ một lớp mờ phản chiếu làn nước nước hoa màu xanh lam bên trong lấp lánh như một viên pha lê của biển cả. Các chữ cái tên thương hiệu theo phong cách Baroque được khéo léo khắc nổi trên phần thân kim của chai như một tác phẩm nghệ thuật.</p><p>Hương thơm mở ra đầy tươi mát và sản khoái của chanh và quýt tượng trưng cho những điều ngọt ngào, để rồi dần thả mình tan vào cùng nốt hương Hồng tiêu nhẹ nhàng nhưng sâu lắng. Sự bùng nổ thật sự phải nối đến đó là sự xuất hiện của những note hương ổi, hoa nhài, gỗ lành, xạ hương, sự kết hợp gợi cảm và tinh tế này mở ra một khía đầy quyến rũ và cuốn hút của người phụ nữ hiện đại.</p>', '2023-09-29 19:13:20', '2023-09-29 19:13:20'),
	(18, 12, 3, 'Tom Ford Ebene Fume Eau De Parfum Travel Spray', 1500000, 'Ấm áp, quyến rũ, bí ẩn', 'H089150', 0, '<p><strong>Nước Hoa Unisex Tom Ford Ebene Fume Eau De Parfum Travel Spray 10ml</strong> là chai nước hoa Unisex cao cấp dành cho cả nam và nữ đến từ thương hiệu Tom Ford nổi tiếng. <strong>Tom Ford Ebene Fume Eau De Parfum Travel Spray </strong>với mùi hương gỗ vô cùng lôi cuốn.</p><p><strong>Nước Hoa Unisex Tom Ford Ebene Fume Eau De Parfum Travel Spray </strong>được ra mắt năm 2021. Hương gỗ là mùi hương bạn dễ cảm nhận khi sử dụng chai nước hoa này.</p><p><strong>Tom Ford Ebene Fume Eau De Parfum Travel Spray 10ml </strong>khiến bất cứ ai cũng phải trầm trồ vì sự thanh lịch, pha chút cổ điển nhưng vẫn giữ được nét sang trọng. Cầm trên tay mới thấy được sự tinh tế mà chai <a href="https://vuahanghieu.com/tom-ford/nuoc-hoa">nước hoa Tom Ford</a> đã tạo nên.</p><p><strong>Nước Hoa Unisex Tom Ford Ebene Fume Eau De Parfum Travel Spray 10ml</strong> mở đầu với mùi tiêu đen cay nồng, gỗ Paolo và mùi khói lên u tối, nhưng chỉ 5 phút sau đó thôi, sự hòa quyện của nhóm mùi da thuộc, labdanum và hoa hồng trên nền cade oil, tạo nên mùi hương cực kỳ lôi cuốn và khó mà nhầm lẫn được.</p><p>Khi Ebene Fume khô dần và đọng lại trên da ở những phút cuối, bạn sẽ thấy mùi hương của những trái nho sấy khô, ngọt ngào và mùi béo béo cùa gỗ Guaiac. Với Tom Ford, những sáng tạo trong nhóm private blend đều xứng đáng được thử và bổ sung vào bộ sưu tập cá nhân, có thể một số chai sẽ không lưu hương lâu, nhưng bù lại mùi hương nào cũng đều tuyệt vời!</p>', '2023-09-29 19:16:09', '2023-09-29 19:16:09'),
	(19, 11, 2, 'Yves Saint Laurent YSL Black Opium Le Parfum', 480000, 'Quyến rũ, nữ tính, lôi cuốn', 'H079489', 0, '<p><strong>Nước Hoa Nữ Yves Saint Laurent YSL Black Opium Le Parfum 8ml</strong>&nbsp;là chai&nbsp;nước hoa dành cho nữ&nbsp;đến từ thương hiệu Yves Saint Laurent. Chai&nbsp;nước hoa YSL Black Opium Le Parfum mang đến một mùi hương mới mẻ năng động và tự tin.</p><p><strong>Nước hoa YSL Black Opium Le Parfum 8ml&nbsp;</strong>là hương nước hoa cho nữ giới được cho ra mắt vào năm 2022 một phiên bản hoàn toàn mới của hương nước hoa đầy cà phê vani quyến rũ, theo xu hướng của các nhà thiết kế khác ngày càng tạo ra các phiên bản đậm đặc hơn, hứa hẹn mang đến một mùi hương lôi cuốn riêng biệt so với những phiên bản trước.</p><p><strong>YSL Black Opium Le Parfum </strong>mang hương thơm ngọt ngào, gợi cảm hơn với nhóm hương Vanilla phươg đông giúp nàng sở hữu một vẻ đẹp đầy quyến rũ, táo bạo khó cưỡng.&nbsp;</p><p><strong>Nước hoa YSL Black Opium Le Parfum 8ml&nbsp;</strong>được thiết kế có dáng vẻ tương tự như những bản trước đó, vẫn là phần chai hình khối trụ nhưng lại không giống như bất kỳ chai Black Opium nào khác, viên ngọc đen quá mức này tỏa sáng từ nắp đến chân với độ bóng phản chiếu nổi bật và sang trọng.&nbsp;</p><p><strong>Nước hoa YSL Black Opium Le Parfum 8ml&nbsp;</strong>lấy mùi hương hoa cỏ nguyên bản của Black Opium và làm nổi bật hương vani, đó là khía cạnh quý giá của hương thơm chứa chai nước hoa này. Hương vị cà phê mang tính biểu tượng đã được biến tấu với sự pha trộn đặc biệt của bốn nốt vani, mỗi nốt khác nhau. Khác nhau, từ những hương thơm ngon lành đến những nốt hương gỗ gợi cảm, bộ tứ thành phần vani đa dạng kết hợp với nhau để tạo ra một sự êm dịu bất ngờ, với cường độ không khoan nhượng.</p><p>Kết hợp với hương vị cà phê đậm đầy phấn khích và những bông hoa trắng sáng, sản phẩm mới này mang dấu ấn Black Opium cổ điển toát lên vẻ gợi cảm cực kỳ mạnh mẽ, đậm nét và tinh tế.&nbsp;</p>', '2023-09-29 19:22:12', '2023-09-29 19:22:12'),
	(20, 8, 2, 'Chanel Les Exclusifs 1957 EDP', 4300000, 'Gợi cảm, lôi Cuốn, tinh tế', 'H093363', 1, '<p><strong>Nước Hoa Nữ Chanel Les Exclusifs 1957 EDP 75ml</strong> là chai nước hoa nữ tính, thanh lịch nhưng không kém phần sang trọng đến từ thương hiệu Chanel nổi tiếng của Pháp. Đây là mùi hương biểu tượng cho tình yêu, sự gắn bó giữa Gabrielle Chanel và nước Mỹ, hương thơm mang đến sự ấm áp đầy khác biệt làm nên một diện mạo mới và khó quên trên làn da của mỗi người.</p><p><strong>Chanel Les Exclusifs 1957 EDP 75ml </strong>được ra mắt vào tháng 2 năm 2019 thuộc bộ sưu tập LES EXCLUSIFS DE CHANEL bởi nhà sáng chế Olivier Polge. Mang trong mình những đặc tính của dòng nước hoa xa xỉ, 1957 là hiện thân cho vẻ đẹp kiêu sa đẳng cấp.&nbsp;</p><p><strong>Nước hoa Chanel Les Exclusifs 1957 EDP 75ml </strong>sở hữu thiết kế chai đơn giản với thân chai thủy tinh thanh mảnh với chiếc nắp màu đen tuyền làm điểm nhấn. Ở trên đầu nắp có in tên logo màu trắng tạo thêm điểm nhấn cho sản phẩm.</p><p>Mùi hương mở đầu bằng hỗn hợp sâu lắng của gỗ, mật ong, nốt hương gia vị pha trộn cùng hương hoa lá. Tạo cảm giác thanh mát sắc sảo mà vẫn toát ra sự mạnh mẽ đầy quyền lực. Tầng hương tiếp theo toả ra sự trầm lắng lạ kỳ qua các nốt hương khác nhau. Vani và mật ong hòa quyện cùng xạ hương trắng, gỗ tuyết tùng, hạt tiêu hồng và nước hoa cam. Khi tiếp xúc lên da, mùi hương này sẽ đánh thức mọi giác quan và lưu lại trên cơ thể bạn hương thơm độc đáo đầy khác biệt.</p><p>Tất cả tạo nên một hương thơm ấn tượng chứa một sức cuốn hút, mê hoặc khiến đối phương phải chững lại ngay từ những phút giây đầu bạn lướt qua.</p>', '2023-09-29 19:34:01', '2023-09-29 19:34:01'),
	(22, 7, 2, 'Dior J\'adore Eau De Toilette', 2000000, 'Quyến rũ, Nữ tính, Sang trọng', 'H104428', 1, '<p><strong>Nước Hoa Nữ Dior J\'adore Eau De Toilette 100ml </strong>là chai nước hoa nữ thuộc bộ sưu tập J\'Adore Dior đến từ thương hiệu Dior Pháp. <strong>Dior J\'adore EDT </strong>là chai nước hoa mang hương thơm nữ tính, quyến rũ và không kém phần sang trọng giúp các nàng tỏa sáng nổi bật theo cách riêng của mình.</p><p><strong>Nước Hoa Nữ Dior J\'adore Eau De Toilette 100ml </strong>là một loại nước hoa dành cho phụ nữ thuộc nhóm hương hoa cỏ nhẹ nhàng, tươi sáng được ra mắt vào năm 2011. Người đứng sau loại nước hoa này là Francois Demachy.<br><strong>Nước Hoa Dior J\'adore Parfum D\'eau EDP</strong> được thiết kế tương tự như những bản trước đó, có hình dạng amphora đặc trưng của J\'adore được sáng tạo lại bằng thủy tinh màu trong suốt với màu hồng nhạt của hương nước hoa cùng chi tiết cổ chai nắp vàng ánh kim toát lên vẻ sang trọng mà ai cũng muốn sở hữu.</p><p><strong>Nước hoa J\'adore Eau De Toilette 100ml&nbsp;</strong>mở ra với hương dầu hoa cam được trồng gần Vallauris - một trong những loài hoa tràn ngập ánh sáng đẹp nổi trội của Grasse Terroir kết hợp cùng hương cam quýt gấp đôi sự tươi mát khiến bạn ngâp trần sự sảng khoái và thư giãn.</p><p>Lớp hương giữa là sự góp mặt của hương hoa vô cùng nữ tính và ngọt ngào với hương hoa nhài thanh nhã, hoa cam châu Phí ấn tượng, hoa huệ nồng nàn, hoa hồng đằm thắm và hoa ngọc lan tây lấp lánh thể hiện được nét nữ tính, thanh lịch và sang trọng.</p><p>Và cuối cùng là chút sâu lắng đầy gợi cảm của nốt hương gỗ và vanilila, sự kết hợp hoàn hảo của của từng nốt hương đều thực sự tỏa sáng khiến các nàng không thể nào thôi đắm say nước hoa <strong>Dior J’adore EDT</strong>này.</p>', '2023-09-30 05:59:51', '2023-09-30 05:59:51'),
	(23, 9, 2, 'Gucci Bloom Eau De Toilette', 1950000, 'Sang trọng, thanh lịch, quyến rũ', 'H081852', 1, '<p><strong>Nước Hoa Nữ Gucci Bloom Eau De Toilette 100ml</strong>&nbsp;là chai&nbsp;nước hoa nữ&nbsp;đến từ thương hiệu Gucci nổi tiếng của Ý. Hương thơm mới này từ dòng sản phẩm Bloom tái hiện lại bản chất Bloom với sự nhẹ nhàng và tươi sáng, đồng thời khuyến khích phụ nữ tỏa sáng một cách đích thực và tự tin.</p><p><strong>Gucci Bloom Eau De Toilette 100ml&nbsp;</strong>được ra mắt vào năm 2022, Gucci Bloom EDT mang trong mình&nbsp;hương thơm hoa cỏ&nbsp;dành cho phái nữ. Những bông hoa trắng: Hoa cam, Hoa huệ và Hoa nhài vẫn luôn là note hương chủ đạo khi bạn sử dụng chai nước hoa này.</p><p><strong>Gucci Bloom Eau De Toilette 100ml&nbsp;</strong>được ra mắt vào năm 2022, Gucci Bloom EDT mang trong mình&nbsp;hương thơm hoa cỏ&nbsp;dành cho phái nữ. Những bông hoa trắng: Hoa cam, Hoa huệ và Hoa nhài vẫn luôn là note hương chủ đạo khi bạn sử dụng chai nước hoa này.</p><p><strong>Gucci Bloom Eau De Toilette 100ml&nbsp;</strong>vẫn gữ nguyên DNA mùi hương chính là những bó hoa trắng muốt, rạng ngời mà không hào nhoáng với Hoa huệ và Hoa nhài. Thế nhưng lần này, lẫn đâu đó trong từng cánh hoa mỏng tang lại thoang thoảng chút sắc sảo, mọng nước đặc trưng của Cam chanh và đượm lại chút đắng ngót như trà non.</p><p>Chỉ cần để ý kỹ hơn, hít một hơi thật đẫy, bạn sẽ còn thấy được dư vị ngọt thanh như trái cây, hương thơm ấy đến từ Hoa sử quân tử đó. Và chính những nụ hoa đỏ tươi, chúm chím mà đáng yêu này đã hình thành nên một Gucci Bloom EDT trẻ trung, hiện đại và mới mẻ hơn rất nhiều.</p>', '2023-09-30 06:27:56', '2023-09-30 06:27:56'),
	(24, 10, 2, 'Burberry Brit For Her EDP', 1240000, 'Ngọt ngào, gợi cảm, nữ tính', 'H058795', 1, '<p><strong>Nước Hoa Nữ Burberry Brit For Her EDP 100ml</strong> là chai nước hoa nữ đến từ thương hiệu Burberry Anh.&nbsp;<strong>Burberry Brit For Her EDP </strong>mang hương thơm gợi cảm vô cùng quyến rũ dành cho các cô nàng yêu thích sự ngọt ngào mà vẫn tinh tế và thanh lịch.&nbsp;</p><p><strong>Nước Hoa Burberry Brit For Her EDP </strong>được ra mắt năm 2003 là mùi hương dành cho nữ, thuộc nhóm hương hoa cỏ trái cây. <strong>Burberry Brit Her</strong> được pha chế bởi Nathalie Gracia-Cetto. Nước hoa này là sự kết hợp tuyệt vời của mùi hương thơm đến từ chanh, lê và hương vani.</p><p>Mùi hương mang một mùi hương nữ tính, đê mê và say đắm, đậm chất truyền thống nhưng lại có một cảm giác của sự hiện đại. Với nước hoa này, bạn sẽ thấy được đặc trưng của người Anh đó là tinh tế, thu hút.</p><p>Chai nước hoa <strong>Burberry Brit For Her EDP</strong> mang đến một hình ảnh trẻ trung đầy cuốn hút với thiết khối thủy tinh quen thuộc của dòng sản phẩm Burberry Brit. Họa tiết kẻ caro nổi tiếng với sắc màu hài hòa mang tới một diện mạo mới mẻ và hấp dẫn hơn cho chai nước hoa.</p><p><strong>Nước hoa Burberry Brit For Her EDP</strong> mở đầu với hương thơm của các loại trái cây như chanh, lê, hạnh nhân. Sự kết hợp của các loại trái cây này tạo ra một hương thơm tươi mát và mát mẻ. Nốt hương giữa thì có các hương liệu như hạnh nhân ngào đường, đường, hạnh nhân. Và nốt hương cuối tạo ra một mùi tươi ngon đến từ sự hòa hợp gỗ gụ, hổ phách, vani, đậu tonka.</p><ul><li>Hương đầu: Hạnh nhân xanh, Sả chanh, Lê, Chanh xanh</li><li>Hương giữa: Hạnh nhân, Đường, Hoa mẫu đơn</li><li>Hương cuối: Gỗ gụ, Vanilla, Hổ phách</li><li>Mùi hương của nước hoa <strong>Burberry Brit For Her EDP</strong> sẽ không nồng nặc và khó chịu cho người sử dụng. Nước hoa sẽ mang đến sự tươi mát, thoải mái, nhẹ nhàng và sự ấm áp phù hợp những ngày thời tiết se lạnh của mà thu hay lạnh giá của mùa đông.</li></ul>', '2023-09-30 06:37:46', '2023-09-30 06:37:46'),
	(25, 7, 2, 'Dior Hypnotic Poison EDT', 2900000, 'Ngọt ngào, quyến rũ', 'H059274', 1, '<p><strong>Nước Hoa Nữ Dior Hypnotic Poison EDT 100ml</strong>&nbsp;là chai nước hoa dành cho nữ đến từ thương hiệu Dior nổi tiếng.&nbsp;<strong>Poison Hypnotic</strong> của hãng Dior là dòng nước hoa vô cùng tự nhiên và cuốn hút với năng lượng và thế mạnh là những nguyên liệu được chọn cẩn thận một cách tuyệt đối.</p><p><strong>Dior Hypnotic Poison EDT</strong>&nbsp;của thương hiệu Christian Dior thuộc nhóm hương thơm Vanilla Phương Đông dành cho phái nữ. Hương thơm được ra mắt vào năm 1998 dưới bàn tay pha chế hương thơm nổi tiếng: Annick Menardo. Dior Hypnotic Poison là một bản mix hoàn hảo của hoa nhài, xạ hương và vani ngọt ngào. Ngông cuồng, bí ẩn, say đắm lòng người ngay từ những note hương đầu.</p><p>Các chai nước hoa của Poison Hypnotic mang biểu tượng một hương thơm của sự bí ẩn, một sự biến hình quyến rũ của trái cấm. Chai thủy tinh được tạo ra bởi các bậc thầy làm thủy tinh Saint-Gobainmàu với đỏ hình trái táo hấp dẫn và cuốn hút sẽ xuất hiện trong màu nham thạch ấm áp được nung chảy dữ dội và nổi bật sự gợi cảm.</p><p>Mở đầu&nbsp;<strong>Hypnotic Poison</strong> được nhấn mạnh bởi note hương hoa quả dịu nhẹ khiến cơ thể các nàng khi vừa khoác nên mình hương thơm này đó thể thả lỏng, gạt bỏ những muộn phiền để sau đó sẵn sàng cho một ngày mới tràn đầy năng lượng tích cực mới. Thêm vào đó những note hương ngọt của Dừa và Mận chín mang đến sự sang trọng, quý phái ngay từ lớp hương đầu.</p><p><strong>Hypnotic Poison</strong>&nbsp;toả ra sắc thái tự nhiên mãnh liệt mang theo sức mạnh của nó với ấn tượng tuyệt đối chắc chắn sẽ khiến người xung quanh chú ý đến bạn. Sự sang trọng xa hoa của Hoa nhài (Jasmine) lẫn với hương hoa cam cuốn hút lan toả một cách nhẹ nhàng mềm mại cùng với sự kích thích sâu sắc của đậu tonka. Lớp hương cam thảo trọn vẹn làm cho nguồn năng lượng quyến rũ của P<strong>Hypnotic Poison</strong>&nbsp;được nâng lên với mức độ thú vị mới. Lớp hương cuối với sự thu hút ấn tượng của vani được đánh giá cao.</p><p>Phiên bản mới Dior&nbsp;<strong>Hypnotic Poison</strong> mang một mùi hương mới cuốn hút dành cho những người phụ nữ hấp dẫn và gợi cảm. Một ít Dior Hypnotic sẽ đẩy mạnh tự tin của bạn trong văn phòng, hoặc ngay cả khi dùng bữa tối với người bạn để ý, dù họ có là người đàn ông lịch lãm cũng khó thể nào cưỡng lại được sự hấp dẫn của bạn.</p><p>&nbsp;</p>', '2023-09-30 06:42:32', '2023-09-30 06:42:32'),
	(26, 11, 2, 'Yves Saint Laurent YSL Libre EDP', 2570000, 'Sang trọng, quyến rũ, ngọt ngào', 'H021054', 1, '<p><strong>Nước Hoa Yves Saint Laurent YSL Libre EDP 90ml</strong> là chai nước hoa nữ sang trọng tới từ thương hiệu YSL Pháp. <strong>Yves Saint Laurent Libre</strong> mang mùi hương thể hiện hình ảnh của người phụ nữ đương đại: mạnh mẽ, chân thực và tự do.</p><p><strong>Yves Saint Laurent Libre</strong> được thương hiệu danh giá Yves Saint Laurent ra mắt vào năm 2019, bởi sự hợp tác ăn ý giữa chai chuyên gia nước hoa Anne Flipo và Carlos Benaim.</p><p>Xóa đi những phù phiếm gần như khiến người ta choáng ngợp, với <strong>YSL Libre</strong> có nghĩa là "Tự do", Yves Saint Laurent muốn mang những vị khách đến với những giới hạn mới hoặc là vô hạn, của tự do. Chính vì ý nghĩa đó, thương hiệu Yves Saint Laurent cũng đã kết hợp với một gương mặt đại diện khác hoàn toàn với những cô đào trước đây, Dua Lipa mới chính là nàng thơ "tự do" của YSL.</p><p><strong>Nước Hoa Yves Saint Laurent Libre EDP 90ml</strong> sở hữu thiết kế đầy táo bạo, sang trọng với sắc vàng sang chảnh, tượng trưng cho những buổi tiệc đêm xa hoa, những nơi sang trọng đầy ánh đèn. Chiếc nắp chai bất đối xứng màu đen như chiếc váy couture gợi cảm, chi tiết những chiếc vòng quấn quanh cổ chai tượng trưng cho những sợi dây chuyền vàng lấp lánh trên chiếc cổ quyến rũ của người phụ nữ, dưới thân chai là chi tiết logo được mạ vàng ôm dọc các cạnh.<br>Mang đến hương vị nồng nàn, ấm áp và giúp cô nàng <strong>Yves Saint Laurent Libre EDP</strong> trở nên ngọt ngào và quyến rũ hơn, nhưng vẫn giữ được độ thanh lịch và tươi mới khi note hương cam vẫn hiện hữu. Sự sang trọng, gợi cảm và cá tính là điều hãng nước hoa YSL muốn gửi gắm đến cô nàng kiêu kỳ này.&nbsp;&nbsp;</p><p>Nước hoa YSL Libre mở đầu với sự bùng nổ từ cam Mandarin, lý chua đen và tinh dầu lá cam, thành phần hương lavender xuất hiện để tô thêm nét mềm mại cho vị tươi mát từ cam chanh. Hoa nhài ở hương giữa tạo nên vẻ đẹp tinh tế, có thể khiến người khác mê mẩn hàng giờ, khi đi cùng với hương lavender thanh lịch. Vì mang phong cách Phương Đông nên nốt cuối của <strong>Yves Saint Laurent Libre</strong> không thể thiếu các thành phần xạ hương, vanilla, tuyết tùng mang đến hương vị nồng nàn, ấm áp, kéo dài dai dẳng đến hàng giờ liền.</p><p><strong>Nước hoa YSL Libre</strong> với nồng độ EDP nên có độ lưu hương kéo dài từ 7 - 12 giờ đồng hồ và độ tỏa hương cũng khoảng 1 cánh tay, đủ để mọi người xung quanh có thể cảm nhận được mùi hương đầy tinh tế. Mùi hương của YSL Libre này có thể sử dụng để đi làm, đi hẹn hò, những cuộc gặp gỡ hay những buổi tiệc đêm sang trọng và lấp lánh ánh đèn.</p>', '2023-09-30 06:56:41', '2023-09-30 06:56:41'),
	(27, 12, 1, 'Tom Ford Grey Vetiver Eau de Parfum', 3000000, 'Nam tính, thu hút, nổi bật', 'H034427', 1, '<p><strong>Nước Hoa Tom Ford Grey Vetiver Eau de Parfum 100ml</strong> là chai nước hoa dành cho nam đến từ thương hiệu Tom Ford nổi tiếng Mỹ. Ngay từ khi có mặt trên thị trường, Tom Ford Grey Vetiver Eau de Parfum được nhiều tín đồ nước hoa săn đón.</p><p>Được ra mắt vào tháng 9 năm 2009, Tom Ford Grey Vetiver là một trong những phiên bản tâm đắc của nhà Tom Ford trong suốt khoảng thời gian vừa qua. Mang đến những cảm giác tươi mới trong hương thơm vô cùng lôi cuốn.</p><p>Thiết kế chai đầy độc đáo với nắm chai dài và thân chai cao, cùng với nắp chai trụ tròn đầy sang trọng. Mẫu chai làm bằng lớp thủy tinh mờ cùng với nắp màu bạc và được trang trí với tấm bảng bằng bạch kim có khắc nhãn hiệu Tom Ford. Điểm nhấn trong thiết kế là những đường rảnh và đường viền trên thân chai màu bạc để lộ màu chất lỏng mờ bên trong. Cầm trên tay chai nước hoa mới có thể thấy hết được sự tinh tế mà nhà Tom Ford đã tạo nên.</p><p>Mang đến những cảm giác tươi mới, độc đáo khi sử dụng tinh chất Bưởi, Hoa cam và Cây xô thơm, tầng hương đầu còn giúp cho tinh thần của bạn trở nên sảng khoái hơn mỗi khi nó phảng phất nơi đầu mũi. Dần cuốn theo một lớp màng ấm áp bao bọc của các nốt hương gỗ và làm sống động lớp hương giữa. Nguồn năng lượng tràn đầy đang dần tỏa ra với hỗn hợp cây orris, đậu khấu và ớt pimento.</p><p>Một làn hương gỗ hổ phách vàng óng ả dẫn mùi hương đến lớp hương cuối đậm đà và hấp dẫn. Rêu sồi mang lại hương xanh tự nhiên và gỗ, chính hương liệu này đã hoàn chỉnh sự hài hòa của nước hoa, tạo cảm giác mát lạnh, nhưng cũng đồng thời mùi hương dường như tan chảy vào thân nhiệt tự nhiên.</p><p>Với dụng ý muốn tạo ra sự đặc trưng riêng biệt của Tom Ford Grey Vetiver, nhà sáng tạo đã khai thác triệt để sự dịu ngọt từ Nhục đậu khấu cùng cảm giác cay nhẹ, nồng ấm từ Ớt Pimento. Có lẽ chính bởi vì sự kết hợp lạ lẫm này mà Tom Ford Grey Vetiver lại trở nên đặc biệt đối với những chàng trai ưa thích sự nổi trội, nam tính mỗi khi xuất hiện nơi đám đông.</p>', '2023-09-30 07:04:40', '2023-09-30 07:04:40');

-- Dumping structure for table perfume_shop.product_images
CREATE TABLE IF NOT EXISTS `product_images` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_images_product_id_foreign` (`product_id`),
  CONSTRAINT `product_images_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table perfume_shop.product_images: ~29 rows (approximately)
INSERT INTO `product_images` (`id`, `product_id`, `image`, `created_at`, `updated_at`) VALUES
	(16, 13, 'uploads/product/Grp36Gbrdb7qvuKxV4p9c3fVWqMenT3JHNEH6NPI.png', '2023-09-28 23:41:35', '2023-09-28 23:41:35'),
	(17, 14, 'uploads/product/UZa836d0yXu5QiL8re8yzgpljNYJjUPs3aCKPr2C.jpg', '2023-09-29 00:06:26', '2023-09-29 00:06:26'),
	(18, 15, 'uploads/product/0nJIrEcViHdZe90XwwM343v3GfahFTW6yqP7zaVC.jpg', '2023-09-29 17:59:23', '2023-09-29 17:59:23'),
	(19, 16, 'uploads/product/D2JVjF4vfGUOAMA1sUK5p2PttQPuI1Fk5flclq5c.jpg', '2023-09-29 18:40:27', '2023-09-29 18:40:27'),
	(20, 16, 'uploads/product/YZxMNT9W3lsnq1qCKt8l0rgLXaEhlujWUweXs0Yh.jpg', '2023-09-29 18:40:27', '2023-09-29 18:40:27'),
	(21, 17, 'uploads/product/OkMDIfNz4jaUAGjhUNhecyqadCAxpyNs5JN4GjRf.jpg', '2023-09-29 19:13:20', '2023-09-29 19:13:20'),
	(22, 17, 'uploads/product/ckLm20yGXzeLX93SYFMOcyjn38FovoFDWu9Y7p81.jpg', '2023-09-29 19:13:20', '2023-09-29 19:13:20'),
	(23, 18, 'uploads/product/rN3Edcez7Q5uCW9UjF1nPHU6JVUc7EwY3YWTWatB.jpg', '2023-09-29 19:16:09', '2023-09-29 19:16:09'),
	(24, 19, 'uploads/product/G99Ny91GwRlMuMdqEbToNjVJSeBCaOwoz5QuvSrN.jpg', '2023-09-29 19:22:12', '2023-09-29 19:22:12'),
	(25, 20, 'uploads/product/juJyZ8rzlGF3iSyhtZKRza5xzb65RA77pnkKUjLd.jpg', '2023-09-29 19:34:01', '2023-09-29 19:34:01'),
	(26, 20, 'uploads/product/VyvOXTCBnauaXI1BEnBrB5TUreD6GVQ3vGiaLP57.jpg', '2023-09-29 19:34:01', '2023-09-29 19:34:01'),
	(27, 20, 'uploads/product/Srlb59LGmDuU8vzgs1udHy3MSQ4aoZJprc4unX16.jpg', '2023-09-29 19:34:01', '2023-09-29 19:34:01'),
	(28, 20, 'uploads/product/oH9bciW5QbyHGHiTo1NiO8QYMk97Edvo7VM5ntYY.jpg', '2023-09-29 19:34:01', '2023-09-29 19:34:01'),
	(30, 22, 'uploads/product/TWbQP4oOcuVBMZzS7z2L8opfws7G8GV3K1xmbxKu.jpg', '2023-09-30 05:59:51', '2023-09-30 05:59:51'),
	(31, 22, 'uploads/product/irxkGapDee5sWe2pd0niVhdQNABW3E1eCdIKBmxG.jpg', '2023-09-30 05:59:51', '2023-09-30 05:59:51'),
	(32, 23, 'uploads/product/QPRMja2vKGJPQ3VGKJXku3GypnHz0iOG5URsqx1f.jpg', '2023-09-30 06:27:56', '2023-09-30 06:27:56'),
	(33, 23, 'uploads/product/iEb79qkrqXXMI4yhwEeylWQW3ngaHVznQkou8BFk.jpg', '2023-09-30 06:27:56', '2023-09-30 06:27:56'),
	(34, 23, 'uploads/product/1ViY7WmSpc1bc1SxvBhBtGRboG81iZJcog18lgCi.jpg', '2023-09-30 06:27:56', '2023-09-30 06:27:56'),
	(35, 24, 'uploads/product/uClFWPlPTCHCYLyJw7nghMT3SIkXV6yq2ctZD8a6.jpg', '2023-09-30 06:37:46', '2023-09-30 06:37:46'),
	(36, 24, 'uploads/product/YIeuGMdf7BqDYvcNy0IwYVwCGraSR614Qtq280PQ.jpg', '2023-09-30 06:37:46', '2023-09-30 06:37:46'),
	(37, 24, 'uploads/product/7p6hHn063e4tv4wVRc9j902bJb7s5rMM3Y0hogmW.jpg', '2023-09-30 06:37:46', '2023-09-30 06:37:46'),
	(38, 25, 'uploads/product/KDi33JhlAXFwV2DWD4lgsd9LFhF0QZRjM4wYWhqv.jpg', '2023-09-30 06:42:32', '2023-09-30 06:42:32'),
	(39, 25, 'uploads/product/vVrugfObXW3UGw2tKnCFRnGde8zqxm3KKtgyJwHL.jpg', '2023-09-30 06:42:32', '2023-09-30 06:42:32'),
	(40, 25, 'uploads/product/V59mJXfVxvyk3rrbH7REAtHNaYHv3799qtYU1fHR.jpg', '2023-09-30 06:42:32', '2023-09-30 06:42:32'),
	(41, 26, 'uploads/product/acA3W9r4OIAOvUjFtARTdFrt2N17rS0AXLYAdyz4.jpg', '2023-09-30 06:56:41', '2023-09-30 06:56:41'),
	(42, 26, 'uploads/product/0Jwmc6QKs5pXLFvOgIlxb1JMCSabk3cPQiHK5poE.jpg', '2023-09-30 06:56:41', '2023-09-30 06:56:41'),
	(43, 26, 'uploads/product/zxF0njvcEjqzblO9gd5F0tg6JwfVlbi1b7tEGBh3.jpg', '2023-09-30 06:56:41', '2023-09-30 06:56:41'),
	(44, 26, 'uploads/product/9J2exq7L8BEvgj3tvCHdZUZ0i001Q2Vj4NmvpNcu.jpg', '2023-09-30 06:56:41', '2023-09-30 06:56:41'),
	(45, 26, 'uploads/product/aTMYIgAgF92HdQvsQWpsf78MtV651i0AhREqqjgN.jpg', '2023-09-30 06:56:41', '2023-09-30 06:56:41'),
	(46, 27, 'uploads/product/JCuqSBuo4uh1jVxJ4UyEhMmk1kE0KD8Y1z0G7neS.png', '2023-09-30 07:04:40', '2023-09-30 07:04:40'),
	(47, 27, 'uploads/product/PG7E8pZgFKuktH1glrB8now6FHpaCSNKt70kaHJB.jpg', '2023-09-30 07:04:40', '2023-09-30 07:04:40');

-- Dumping structure for table perfume_shop.product_items
CREATE TABLE IF NOT EXISTS `product_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `size` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_items_product_id_foreign` (`product_id`),
  CONSTRAINT `product_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table perfume_shop.product_items: ~14 rows (approximately)
INSERT INTO `product_items` (`id`, `product_id`, `size`, `quantity`, `created_at`, `updated_at`) VALUES
	(16, 13, '30', 40, '2023-09-28 23:41:34', '2023-09-28 23:41:34'),
	(17, 14, '100', 20, '2023-09-29 00:06:26', '2023-09-29 00:06:26'),
	(18, 15, '90', 10, '2023-09-29 17:59:23', '2023-09-29 17:59:23'),
	(19, 16, '90', 19, '2023-09-29 18:40:27', '2023-09-29 18:40:27'),
	(20, 17, '100', 20, '2023-09-29 19:13:20', '2023-09-29 19:13:20'),
	(21, 18, '10', 30, '2023-09-29 19:16:09', '2023-09-29 19:16:09'),
	(22, 19, '8', 45, '2023-09-29 19:22:12', '2023-09-29 19:22:12'),
	(23, 20, '75', 33, '2023-09-29 19:34:01', '2023-09-30 06:51:46'),
	(25, 22, '100', 45, '2023-09-30 05:59:51', '2023-09-30 05:59:51'),
	(26, 23, '100', 15, '2023-09-30 06:27:56', '2023-09-30 06:27:56'),
	(27, 24, '100', 14, '2023-09-30 06:37:46', '2023-09-30 06:37:46'),
	(28, 25, '100', 39, '2023-09-30 06:42:32', '2023-10-01 03:16:06'),
	(29, 26, '90', 21, '2023-09-30 06:56:41', '2023-10-03 23:28:14'),
	(30, 27, '100', 33, '2023-09-30 07:04:40', '2023-10-03 23:28:14');

-- Dumping structure for table perfume_shop.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table perfume_shop.users: ~0 rows (approximately)
INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`, `updated_at`) VALUES
	(6, 'Duong Phi', 'test1@gmail.com', '$2y$10$gVh7mlxTnHQd0jvl5OHI1eHz.5D/l7972tgjkQHFgxoE8fU6jwshi', '2023-09-30 06:51:22', '2023-09-30 06:51:22'),
	(7, 'quang vu', 'vuquang@gmail.com', '$2y$10$wQTlk6x2vacEfed2RTlcZe85rugZGCsIIegoTKohfliyvsSIY6UiC', '2023-10-03 23:26:59', '2023-10-03 23:26:59');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
