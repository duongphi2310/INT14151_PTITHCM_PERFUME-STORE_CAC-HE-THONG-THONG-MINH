<!DOCTYPE html>
<html>
<head>
    <title>Tìm kiếm thông tin</title>
</head>
<body>
    <form method="POST" action="<?php echo e(route('search')); ?>">
        <?php echo csrf_field(); ?>
        <label for="keyword">Nhập từ khóa:</label>
        <input type="text" name="keyword" id="keyword" required>
        <button type="submit">TÌM</button>
    </form>
    <?php if(isset($searchResult)): ?>
    <h2>Kết quả tìm kiếm:</h2>
    <p><?php echo e($searchResult); ?></p>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\laragon\www\perfume_store\resources\views/search.blade.php ENDPATH**/ ?>