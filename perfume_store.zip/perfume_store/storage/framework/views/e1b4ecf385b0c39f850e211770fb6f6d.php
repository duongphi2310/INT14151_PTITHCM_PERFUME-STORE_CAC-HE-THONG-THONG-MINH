<?php $__env->startSection('content'); ?>
<style> input.custom-input{ height: 35px; width: 120px; } .custom-btn{ height: 30px; width: 55px; } .price-divider{
    margin: 25px 15px 0 15px; } </style> <!-- Shop Start -->
    <div class="container-fluid pt-5"> <form action=""> <div class="row px-xl-5">
        <!-- Shop Sidebar Start -->
        <div class="col-lg-3 col-md-12">
        <!-- Price Filter Start -->
        <div class="border-bottom mb-4 pb-4"> <h5 class="font-weight-semi-bold mb-4">LỌC THEO GIÁ</h5> <div
            class="d-flex align-items-center">
            <div class="mr-3">
            <label class="" for="">TỪ</label>
            <div class="price-filter-input d-flex align-items-center">
                <label>
                <input class="custom-input" value="<?php echo e(request('min_price') ?? ''); ?>" type="number" name="min_price"
                placeholder="0" min="0">
                </label>
                </div>
                </div>
                <div class="mr-3">
                    <div class="price-divider">
                    <span>-></span>
                </div>
                </div>
                <div>
                <label class="price-filter-label" for="">ĐẾN</label>
                <div class="price-filter-input d-flex align-items-center">
                <label>
                <input class="custom-input" value="<?php echo e(request('max_price') ?? ''); ?>" type="number" placeholder="0"
                    name="max_price" min="0">
                </label>
                </div>
            </div>
            <button class="btn-primary mt-3 custom-btn" type="submit">LỌC</button>
            </div>
        </div>
        <!-- Price Filter End -->

    <!-- Brand Filter Start -->
        <div class="brand-header"> <h5 class="font-weight-semi-bold mb-4">LỌC THEO THƯƠNG HIỆU</h5> </div>

            <div class="brand-container">
            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="custom-control d-flex align-items-center mb-3">
            <input onchange="this.form.submit()" type="checkbox" class="custom-control-input" id="brand-<?php echo e($brand->id); ?>"
            name="brand[<?php echo e($brand->name); ?>]" <?php echo e((request('brand')[$brand->name] ?? '') == 'on' ? 'checked' : ''); ?>>
            <label class="custom-control-label" for="brand-<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></label>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- Brand Filter End -->

    <!-- Size Filter Start -->
        <div class="mb-5 d-flex align-items-center justify-content-between" style="margin-top: 15px;"> <h5
            class="font-weight-semi-bold mb-4">LỌC THEO THỂ TÍCH</h5> <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <div
            class="custom-control d-flex align-items-center justify-content-between mb-3"> <input type="checkbox"
            class="custom-control-input" id="size-<?php echo e($size); ?>" name="size[<?php echo e($size); ?>]" <?php echo e((request('size')[$size] ?? ''
            )=='on' ? 'checked' : ''); ?> onchange="this.form.submit()"> <label class="custom-control-label"
            for="size-<?php echo e($size); ?>"><?php echo e($size); ?>ml</label>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- Size Filter End -->
</div>

                <!-- Shop Sidebar End -->
    
                <!-- Shop Product Start -->
        <div class="col-lg-9 col-md-12">
        <div class="row pb-3">
        <div class="col-12 pb-1">
            <div class="d-flex align-items-center justify-content-between mb-4">
            <div class="ml-4">
            <label>Sắp xếp theo :</label>
            <select name="sort_by" onchange="this.form.submit()">
            <option <?php echo e(request('sort_by') == 'latest' ? 'selected' : ''); ?> value="lastest">MỚI NHẤT</option>
            <option <?php echo e(request('sort_by')=='oldest' ? 'selected' : ''); ?> value="oldest">CŨ NHẤT</option>
            <option <?php echo e(request('sort_by')=='name-ascending' ? 'selected' : ''); ?> value="name-ascending">TÊN A -> Z
            </option>
            <option <?php echo e(request('sort_by')=='name-desending' ? 'selected' : ''); ?> value="name-desending">TÊN Z -> A
            </option>
            <option <?php echo e(request('sort_by')=='price-ascending' ? 'selected' : ''); ?> value="price-ascending">GIÁ TĂNG DẦN
            </option>
            <option <?php echo e(request('sort_by')=='price-desending' ? 'selected' : ''); ?> value="price-desending">GIÁ GIẢM DẦN
            </option>
            </select>
        </div>
        <div class="ml-4">
            <div>
                <p class="text-sm text-gray-700 leading-5">
                    Đang hiển thị
                    <span class="font-medium"><?php echo e($products->firstItem()); ?></span>
                    -
                    <span class="font-medium"><?php echo e($products->count()); ?></span>
                    trong tổng số
                    <span class="font-medium"><?php echo e($products->total()); ?></span>
                    kết quả.
                </p>
            </div>
        </div>
    </div>
    </div>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-4 col-md-6 col-sm-12 pb-1">
        <div class="card product-item border-0 mb-4">
            <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                <img class="img-fluid w-100" src="<?php echo e($product->images->shift()->image); ?>" alt="">
            </div>
            <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                <h6 class="text-truncate mb-3"><?php echo e($product->name); ?></h6>
                <div class="d-flex justify-content-center">
                    <h6 class="text-danger font-weight-bold"><?php echo e(number_format($product->price)); ?>đ</h6>
                </div>
            </div>
            <div class="card-footer d-flex justify-content-center bg-light border">
                <a href="<?php echo e(route('product', $product)); ?>" class="btn btn-sm text-dark p-0"><i
                        class="fas fa-eye text-primary mr-1"></i>XEM</a>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="col-12 pb-1">
        <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center mb-3">
                <?php echo e($products->links()); ?>

            </ul>
        </nav>
    </div>
    </div>
    </div>
    <!-- Shop Product End -->
    </div>
    </form>
    </div>
    <!-- Shop End -->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perfume_store\resources\views/frontend/shop.blade.php ENDPATH**/ ?>