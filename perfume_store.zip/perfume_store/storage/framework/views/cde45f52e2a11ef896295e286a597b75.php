<?php $__env->startSection('content'); ?>
    <!-- Checkout Start -->
    <div class="container-fluid pt-5">
        <form method="POST" action="<?php echo e(route('checkoutPost')); ?>">
            <?php echo csrf_field(); ?>
            <div class="row px-xl-5">
                <div class="col-lg-7 pl-5">
                    <div class="mb-4">
                        <h4 class="font-weight-semi-bold mb-4">ĐỊA CHỈ NHẬN HÀNG</h4>
                        <div class="row">
                            <div class="col-md-12 form-group">
                                <label>HỌ TÊN NGƯỜI NHẬN</label>
                                <input class="form-control" value="<?php echo e(Auth::guard('web')->user()->name); ?>" name="name" type="text" placeholder="Nhập họ tên">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-12 form-group">
                                <label>E-MAIL</label>
                                <input class="form-control" value="<?php echo e(Auth::guard('web')->user()->email); ?>" type="email" name="email" placeholder="Nhập e-mail">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-12 form-group">
                                <label>SỐ ĐIỆN THOẠI NGƯỜI NHẬN</label>
                                <input class="form-control" type="number" name="phone" placeholder="Nhập số điện thoại">
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-12 form-group">
                                <label>ĐỊA CHỈ NGƯỜI NHẬN</label>
                                <input class="form-control" type="text" name="address" placeholder="Nhập địa chỉ">
                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 pr-5">
                    <div class="card border-secondary mb-5">
                        <div class="card-header bg-secondary border-0">
                            <h4 class="font-weight-semi-bold m-0">CHI TIẾT ĐƠN HÀNG</h4>
                        </div>
                        <div class="card-body">
                            <h5 class="font-weight-medium mb-3">SẢN PHẨM</h5>
                            <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex justify-content-between">
                                    <p><?php echo e($cart['name']); ?> - <?php echo e($cart['size']); ?>ml x <?php echo e($cart['quantity']); ?></p>
                                    <p><?php echo e(number_format($cart['price'] * $cart['quantity'])); ?>đ</p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        
                            <hr class="mt-0">
                            <div class="d-flex justify-content-between mb-3 pt-1">
                                <h6 class="font-weight-medium">TỔNG TIỀN HÀNG</h6>
                                <h6 class="font-weight-medium"><?php echo e(number_format(session('total_price'))); ?>đ</h6>
                            </div>
                            <div class="d-flex justify-content-between">
                                <h6 class="font-weight-medium">PHÍ VẬN CHUYỂN</h6>
                                <h6 class="font-weight-medium">MIỄN PHÍ</h6>
                            </div>
                        </div>
                        <div class="card-footer border-secondary bg-transparent">
                            <div class="d-flex justify-content-between mt-2">
                                <h5 class="font-weight-bold">THÀNH TIỀN</h5>
                                <h5 class="font-weight-bold"><?php echo e(number_format(session('total_price'))); ?>đ</h5>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer border-secondary bg-transparent">
                        <button type="submit" class="btn btn-lg btn-block btn-primary font-weight-bold my-3 py-3">ĐẶT HÀNG</button>
                    </div>
                </div>
            </div>
        </form>
        
    </div>
    <!-- Checkout End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perfume_store\resources\views/frontend/checkout.blade.php ENDPATH**/ ?>