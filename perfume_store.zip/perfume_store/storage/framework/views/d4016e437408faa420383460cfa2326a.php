<?php $__env->startSection('content'); ?>

<!-- Shop Detail Start -->
<div class="container-fluid py-5">
    <?php if(session('success')): ?>
    <div class="alert alert-success">
    <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <div class="row px-xl-5">
    <div class="col-lg-5 pb-5">
    <div id="product-carousel" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner border">
        <div class="carousel-item active">
        <img class="w-100 h-100" src="<?php echo e($product->images->shift()->image); ?>" alt="Image">
        </div>

        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="carousel-item">
        <img class="w-100 h-100" src="<?php echo e($item->image); ?>" alt="Image">
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<a class="carousel-control-prev" href="#product-carousel" data-slide="prev">
<i class="fa fa-2x fa-angle-left text-dark"></i>
</a>
<a class="carousel-control-next" href="#product-carousel" data-slide="next">
<i class="fa fa-2x fa-angle-right text-dark"></i>
</a>
</div>
</div>

<div class="col-lg-7 pb-5">
<form action="<?php echo e(route('cart.add', $product)); ?>" method="post">
<?php echo csrf_field(); ?>
<h3 class="font-weight-semi-bold"><?php echo e($product->name); ?></h3>
<p class="font-weight-semi-bold"><?php echo e($product->category->name); ?></p>

<h3 class="font-weight-bold mb-4 text-danger"><?php echo e(number_format($product->price)); ?>đ</h3>
<p class="mb-3">MÃ SẢN PHẨM: <?php echo e(($product->product_code)); ?></p>

<p class="mb-3">TÌNH TRẠNG:
<?php if($product->productItems->sum('quantity') > 0): ?>
<span class="text-success">SẴN HÀNG</span>
<?php endif; ?>
</p>

<?php if($product->productItems->sum('quantity') > 0): ?>
<div class="d-flex mb-4" >
<p class="text-dark font-weight-medium mb-0 mr-3">DUNG TÍCH:</p>
<div class="custom-control custom-radio custom-control-inline">
<input value="<?php echo e($product->productItems->size); ?>" onchange="getQuantity('<?php echo e($product->productItems->size); ?>',<?php echo e($product->id); ?>);"
type="radio" class="custom-control-input" id="size-<?php echo e($product->productItems->size); ?>" name="size">
<label class="custom-control-label"
for="size-<?php echo e($product->productItems->size); ?>"><?php echo e($product->productItems->size); ?>ml</label>
</div>
</div>
<?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<p style="margin-top:-20px;" class="text-danger"><?php echo e($message); ?></p>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<h5 id="showQuantity" class="mb-4 text-info font-weight-bold"></h5>

<div class="d-flex align-items-center mb-4 pt-2">
    <div class="input-group quantity mr-3" style="width: 130px;">
    <div class="input-group-btn">
    <button type="button" class="btn btn-primary btn-minus">
        <i class="fa fa-minus"></i>
        </button>
</div>
<input type="number" name="quantity" class="form-control bg-secondary text-center" value="1">
<div class="input-group-btn">
<button type="button" class="btn btn-primary btn-plus">
    <i class="fa fa-plus"></i>
    </button>
    </div>
    </div>
    <button type="submit" class="btn btn-primary px-3"><i class="fa fa-shopping-cart mr-1"></i> THÊM VÀO GIỎ
    HÀNG</button>
    </div>
    <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p style="margin-top:-20px;" class="text-danger"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php else: ?>
    <h1 class="text-danger ">HẾT HÀNG</h1>
    <?php endif; ?>

    </form>
    </div>
    </div>
    <div class="row px-xl-5">
        <div class="col">
            <div class="nav nav-tabs justify-content-center border-secondary mb-4">
                <a class="nav-item nav-link active" data-toggle="tab" href="#tab-pane-1">MÔ TẢ</a>

            </div>
            <div class="tab-content">
                <div class="tab-pane fade show active" id="tab-pane-1">
                    <h4 class="mb-3">MÔ TẢ SẢN PHẨM</h4>
                    <p><?php echo $product->description; ?></p>
                </div>

            </div>
        </div>
    </div>
    </div>
    <!-- Shop Detail End -->


    <!-- Products Start -->
    <div class="container-fluid py-5">
        <div class="text-center mb-4">
            <h2 class="section-title px-5"><span class="px-2">Bạn Có Thể Thích</span></h2>
        </div>
        <div class="row px-xl-5 pb-3">
            <?php $__currentLoopData = $relatedProductsSameBrand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-2 col-md-4 col-sm-6 pb-1">
                <div class="card product-item border-0 mb-4">
                    <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                    <img class="img-fluid w-100" src="<?php echo e($product->images->first()->image); ?>" alt="">
                    </div>
                    <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                        <h6 class="text-truncate mb-3"><?php echo e($product->name); ?></h6>
                        <div class="d-flex justify-content-center">
                            <h6 class="text-danger font-weight-bold"><?php echo e(number_format($product->price)); ?>₫</h6>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-center bg-light border">
                        <a href="<?php echo e(route('product', $product)); ?>" class="btn btn-sm text-dark p-0">
                            <i class="fas fa-eye text-primary mr-1"></i>XEM
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <!-- Products End -->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perfume_store\resources\views/frontend/product.blade.php ENDPATH**/ ?>