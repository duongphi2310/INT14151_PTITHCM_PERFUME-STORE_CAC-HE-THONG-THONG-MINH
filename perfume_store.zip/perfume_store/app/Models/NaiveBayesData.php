<?php
namespace App;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;

class NaiveBayesData extends Model
{
    protected $fillable = ['model_name', 'model_data', 'data', 'labels', 'user_id'];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
