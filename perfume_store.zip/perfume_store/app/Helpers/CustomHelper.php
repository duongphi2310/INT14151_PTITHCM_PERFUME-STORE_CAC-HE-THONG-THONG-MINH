<?php
use App\Models\Cart;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use App\NaiveBayesData;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Phpml\Classification\NaiveBayes;
use function PHPUnit\Framework\isEmpty;

if (!function_exists('loadCart')) {
    /**
     * Summary of loadCart
     * @param User $user
     * @return bool
     */
    function loadCart(int $id)
    {
        $user = User::find($id);
        $cartItems = Cart::where('user_id', $user->id)->get();

        // Chuyển dữ liệu từ mảng thành một mảng liên hợp dựa trên product_id
        $cart = session('cart', []);
        foreach ($cartItems as $item) {
            $product = $item->product;
            if ($product) {
                $cart[$item->product_id] = [
                    'product_id' => $item->product_id,
                    'image' => $product->images->first()->image,
                    'name' => $product->name,
                    'quantity' => $item->quantity,
                    'size' => $item->size,
                    'price' => $product->price,
                ];
            } else {
                // Xảy ra lỗi khi không tìm thấy thông tin sản phẩm
                return false;
            }
        }

        session(['cart' => $cart]);
        $total_price = 0;
        if (!empty($_SESSION['cart'])) {
            $total_price = session('total_price', 0);
            foreach (session('cart') as $item) {
                $total_price += $item['quantity'] * $item['price'];
            }
            session()->put('total_price', $total_price);
        }
        return true; // Trả về true nếu mọi thao tác hoàn thành thành công
    }
}

if (!function_exists('trainForEachPersonWithOrders')) {
    function trainForEachPersonWithOrders()
    {
        $orders = Order::where('user_id', Auth::user()->id)->get();
        $productsHasSeen = session('productsHasSeen', []);
        // chuan bị du lieu de train
        $data = [];
        $labels = [];
        $productsOfOrder = [];
        if (!($orders->isEmpty())) {
            foreach ($orders as $order) {
                foreach ($order as $product) {
                    $productsOfOrder[] = $product;
                }
            }

            foreach ($productsOfOrder as $product) {
                if ($product->price <= 1000000) {
                    $phanKhuc = 'phothong';
                } elseif ($product->price > 1000000 && $product->price <= 2000000) {
                    $phanKhuc = 'tamtrung';
                } elseif ($product->price > 2000000) {
                    $phanKhuc = 'caocap';
                }
                $data[] = [$product->id, $product->brand_id, $product->category_id, $phanKhuc];
                $labels[] = "yes";
            }
        }

        
        // dem so lan xuat hien cua mot san pham
        $countProductHasSeen = array_count_values($productsHasSeen);
        foreach ($countProductHasSeen as $product=>$count) {
            if ($product->price <= 1000000) {
                $phanKhuc = 'phothong';
            } elseif ($product->price > 1000000 && $product->price <= 2000000) {
                $phanKhuc = 'tamtrung';
            } elseif ($product->price > 2000000) {
                $phanKhuc = 'caocap';
            }
            $data[] = [$product->id, $product->brand_id, $product->category_id, $phanKhuc];
            if ($count >= 2) {
                $labels[] = "yes";
            } else {
                $labels[] = "no";
                $data[] = [$product->id, $product->brand_id, $product->category_id, $phanKhuc];
                $labels[] = "yes";
            }
        }

        // Tạo mô hình Naive Bayes
        $classifier = new NaiveBayes();
        $classifier->train($data, $labels);

        // cho du doan toan bo san pham cua cua hang
        $shopProducts = Product::all();
        $dataForPredict = [];

        foreach ($shopProducts as $product) {
            if ($product->price <= 1000000) {
                $phanKhuc = 'phothong';
            } elseif ($product->price > 1000000 && $product->price <= 2000000) {
                $phanKhuc = 'tamtrung';
            } elseif ($product->price > 2000000) {
                $phanKhuc = 'caocap';
            }
            $dataForPredict[] = [$product->id, $product->brand_id, $product->category_id, $phanKhuc];

        }
        // tập hợp các bản ghi mới theo xác suất của lớp "yes"
        // Tạo một mảng để lưu các bản ghi được dự đoán là "Có" cùng với xác suất tương ứng

        $predictedLabel = [];

        foreach ($dataForPredict as $dataPoint) {
            // Dự đoán lớp dự đoán và tính toán xác suất
            $labelDataPoint = $classifier->predict($dataPoint);

            $predictedLabel[] = $labelDataPoint;

        }

        // Tạo một bản ghi mới trong bảng naive_bayes_data
        $naiveBayesData = new NaiveBayesData();

        // Chuẩn bị dữ liệu để lưu
        $naiveBayesData->model_name = Carbon::now()->toDateString();
        $naiveBayesData->model_data = serialize($classifier); // Lưu mô hình Naive Bayes
        $naiveBayesData->data = serialize($data); // Lưu dữ liệu huấn luyện
        $naiveBayesData->labels = serialize($labels); // Lưu nhãn tương ứng
        $naiveBayesData->user_id = Auth::user()->id;

        // Lưu bản ghi vào cơ sở dữ liệu
        $naiveBayesData->save();
        // // lay ra nhieu nhat 6 san pham tu lich su xem hang gan day nhat 
        // $last6Products = array_slice($productsHasSeen, -6);
        // $relateProductsHasSeen = [];
        // $count = 6;
        // while (!empty($last6Products) && $count <= 6) {
        //     $relateProductsHasSeen[] = array_pop($last6Products);
        //     $count -= 1;
        // }
    }
}

if (!function_exists('trainForEachPerson')) {
    function trainForEachPerson()
    {
        $orders = Order::where('user_id', Auth::user()->id)->get();
        $productsHasSeen = session('productsHasSeen', []);

        // chuan bị du lieu de train
        $data = [];
        $labels = [];
        $productsOfOrder = [];
        if (!($orders->isEmpty())) {
            foreach ($orders as $order) {
                foreach ($order as $product) {
                    $productsOfOrder[] = $product;
                }
            }

            foreach ($productsOfOrder as $product) {
                if ($product->price <= 1000000) {
                    $phanKhuc = 'phothong';
                } elseif ($product->price > 1000000 && $product->price <= 2000000) {
                    $phanKhuc = 'tamtrung';
                } elseif ($product->price > 2000000) {
                    $phanKhuc = 'caocap';
                }
                $data[] = [$product->id, $product->brand_id, $product->category_id, $phanKhuc];
                $labels[] = "yes";
            }
        }
        if (!($productsHasSeen->isEmpty())) {
            foreach ($productsHasSeen as $product) {
                if ($product->price <= 1000000) {
                    $phanKhuc = 'phothong';
                } elseif ($product->price > 1000000 && $product->price <= 2000000) {
                    $phanKhuc = 'tamtrung';
                } elseif ($product->price > 2000000) {
                    $phanKhuc = 'caocap';
                }
                $data[] = [$product->id, $product->brand_id, $product->category_id, $phanKhuc];
                $labels[] = "yes";
            }
        }
        // Tạo mô hình Naive Bayes
        $classifier = new NaiveBayes();
        $classifier->train($data, $labels);

        // cho du doan toan bo san pham cua cua hang
        $shopProducts = Product::all();
        $dataForPredict = [];

        foreach ($shopProducts as $product) {
            if ($product->price <= 1000000) {
                $phanKhuc = 'phothong';
            } elseif ($product->price > 1000000 && $product->price <= 2000000) {
                $phanKhuc = 'tamtrung';
            } elseif ($product->price > 2000000) {
                $phanKhuc = 'caocap';
            }
            $dataForPredict[] = [$product->id, $product->brand_id, $product->category_id, $phanKhuc];

        }
        // tập hợp các bản ghi mới theo xác suất của lớp "yes"
        // Tạo một mảng để lưu các bản ghi được dự đoán là "Có" cùng với xác suất tương ứng

        $predictedLabel = [];

        foreach ($dataForPredict as $dataPoint) {
            // Dự đoán lớp dự đoán và tính toán xác suất
            $labelDataPoint = $classifier->predict($dataPoint);

            $predictedLabel[] = $labelDataPoint;

        }

        // usort($predictedData, function ($a, $b) {
        //     return $b['probability'] <=> $a['probability'];
        // });

        // tìm sản phẩm có thể gợi ý từ predictedData
        // $highLightProducts = [];
        // foreach ($productsWithoutOrders as $item) {
        //     foreach ($predictedData as $predictedItem) {
        //         if ($item->id == $predictedItem[0]) {
        //             $highLightProducts[] = $item;
        //             break;
        //         }
        //     }
        // }


        // // lay ra nhieu nhat 6 san pham tu lich su xem hang gan day nhat 
        // $last6Products = array_slice($productsHasSeen, -6);
        // $relateProductsHasSeen = [];
        // $count = 6;
        // while (!empty($last6Products) && $count <= 6) {
        //     $relateProductsHasSeen[] = array_pop($last6Products);
        //     $count -= 1;
        // }
    }
}

if (!function_exists('getHasSeen')) {
    function getHasSeen()
    {
        $hasSeen = session('hasSeen', []);
        $hasSeen = DB::table('detail_has_seen')->where('user_id', Auth::user()->id)->get();
        session(['hasSeen' => $hasSeen]);
        return $hasSeen;
    }
}

if (!function_exists('updateHasSeen')) {
    function updateHasSeen($userId, $productId)
    {
        try {
            DB::table('detail_has_seen')->insert([
                'user_id' => $userId,
                'product_id' => $productId,
            ]);
        } catch (\Exception $e) {
            // error_log("error update hasSeen");
            Log::error('error update hasSeen');
        }
    }
}