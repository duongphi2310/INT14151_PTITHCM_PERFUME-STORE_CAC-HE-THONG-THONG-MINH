<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;

class SearchController extends Controller
{
    public function index()
    {
        return view('search');
    }

    // public function search(Request $request)
    // {
    //     $keyword = $request->input('keyword');
    //     // Gán từ khóa vào biến user_description trong file Python
    //     exec("python path/to/your_script.py $keyword", $output);
    //     $searchResult = implode("\n", $output);
    //     return view('search', compact('searchResult'));
    // }
    public function search(Request $request)
    {
        $keyword = $request->input('keyword');

        # $command = "python D:\main.py $keyword";
        $command = "python D:/main.py \"$keyword\"";
        $output = shell_exec($command);

        // Chuyển chuỗi JSON thành mảng hoặc đối tượng trong PHP
        $result = json_decode($output, true); // Sử dụng true để chuyển thành mảng
        // dd($result);
        // Xử lý dữ liệu trong biến $result
        // Ví dụ: lấy danh sách sản phẩm tương tự từ JSON
        $similar_perfumes = $result['similar_perfumes'];
        // dd($similar_perfumes);
        $products = [];
        foreach ($similar_perfumes as $index => $item) {
            $curr = Product::where('name', 'LIKE', '%' . $item . '%')->get();
            $products[] = $curr[0];
        }
        // dd($highLightProducts);
        return view('frontend.findpy', compact('products'));
    }


}
