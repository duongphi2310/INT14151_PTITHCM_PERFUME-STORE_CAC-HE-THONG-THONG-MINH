<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Auth;
use DB;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\ProductItem;

use App\Models\Order;

// require 'vendor/autoload.php';
use Phpml\Classification\NaiveBayes;
use Phpml\Classification\DecisionTree;
use PHPUnit\Framework\Constraint\IsEmpty;


class ShopController extends Controller
{
    public function index()
    {
        $highLightProducts = Product::orderByDesc('id')->where('featured', 1)->limit(100)->get();
        // $products = Product::orderByDesc('id')->limit(8)->get();
        // $highLightProducts = Product::inRandomOrder()->limit(18)->get();

        // $userDescription = "Trẻ trung, dịu dàng, nữ tính";
        // $pythonScriptPath = "D:/PT-HTTM/Nhap/main.py";
        // $command = "python " . escapeshellarg($pythonScriptPath) . " " . escapeshellarg($userDescription);
        // $output = shell_exec($command);
        // $output = utf8_encode($output); // Thêm dòng này

        // // dd($output);
        // // Tách chuỗi đầu ra thành mảng các tên sản phẩm
        // $products = explode("\n", trim($output));
        // // // Lấy danh sách các tên sản phẩm
        // $productNames = [];
        // foreach ($products as $index => $name) {
        //     $productNames[] = $name;
        // }
        // // Hiển thị danh sách tên sản phẩm
        // // dd($productNames);
        // $highLightProducts = [];
        // foreach ($productNames as $item) {
        //     $highLightProducts[] = Product::where('name', $item)->first();
        // }
        // dd($highLightProducts);


        // $command = "python D:/PT-HTTM/Nhap/main.py \"Trẻ trung, ngọt ngào, quyến rũ\"";
        // $output = shell_exec($command);
        // dd($output);


        return view('frontend.index', compact('highLightProducts'));
    }




    public function contact()
    {
        return view('frontend.contact');
    }

    public function shop(Request $request)
    {
        $sizes = ProductItem::all()->unique('size')->pluck('size')->sort();

        $keyword = $request->input('search');
        $products = Product::when($keyword, function ($query, $keyword) {
            return $query->where('name', 'like', "%$keyword%");
        });

        $products = $this->filter($products, $request);
        $products = $this->sortBy($products, $request);
        $products = $products->paginate(9);

        return view('frontend.shop', compact('products', 'sizes'));
    }

    public function getProductByCategory($category_id, Request $request)
    {
        $sizes = ProductItem::all()->unique('size')->pluck('size')->sort();

        $products = Product::where('category_id', $category_id);

        $products = $this->filter($products, $request);
        $products = $this->sortBy($products, $request);
        $products = $products->paginate(9);

        return view('frontend.shop', compact('products', 'sizes'));
    }

    protected function filter($products, Request $request)
    {

        //Brand
        $brands = $request->input('brand') ?? [];
        $brand_names = array_keys($brands);
        if ($brand_names != null) {
            $products = $products->whereHas('brand', function ($query) use ($brand_names) {
                return $query->whereIn('name', $brand_names);
            });
        }

        //Price
        $min_price = $request->input('min_price');
        $max_price = $request->input('max_price');

        $products = ($min_price != null && $max_price != null)
            ? $products->whereBetween('price', [$min_price, $max_price]) : $products;

        //Size
        $sizes = $request->input('size') ?? [];
        $arr_sizes = array_keys($sizes);

        $products = $arr_sizes != null ? $products->whereHas('productItems', function ($query) use ($arr_sizes) {
            return $query->whereIn('size', $arr_sizes)
                ->where('quantity', '>', '0');
        }) : $products;

        return $products;
    }

    protected function sortBy($products, Request $request)
    {
        $sortBy = $request->input('sort_by') ?? 'latest';

        switch ($sortBy) {
            case 'latest':
                $products = $products->orderByDesc('id');
                break;
            case 'oldest':
                $products = $products->orderBy('id');
                break;
            case 'name-ascending':
                $products = $products->orderBy('name');
                break;
            case 'name-desending':
                $products = $products->orderByDesc('name');
                break;
            case 'price-ascending':
                $products = $products->orderBy('price');
                break;
            case 'price-desending':
                $products = $products->orderByDesc('price');
                break;
            default:
                $products = $products->orderByDesc('id');
        }

        return $products;
    }

    public function product(Product $product)
    {
        // updateHasSeen(Auth::id(), $product->id);
        // $hasSeen = getHasSeen();

        // $userId = Auth::id();
        // $productIds = DB::table('detail_has_seen')
        //     ->where('user_id', $userId)
        //     ->pluck('product_id')
        //     ->toArray();

        // $relatedProductsHasSeen = Product::whereIn('id', $productIds)->get();

        // trainForEachPersonWithOrders();

        $relatedProductsSameBrand = Product::where('brand_id', $product->brand_id)
            ->where('id', '!=', $product->id) // Loại bỏ sản phẩm hiện tại
            ->distinct()
            ->limit(8)
            ->get();

        // $relatedProductsSameCategory = Product::where('category_id', $product->category_id)
        //     ->where('id', '!=', $product->id) // Loại bỏ sản phẩm hiện tại
        //     ->distinct()
        //     ->limit(8)
        //     ->get();

        // return view('frontend.product', compact('product', 'relatedProductsSameBrand', 'relatedProductsSameCategory'));
        return view('frontend.product', compact('product', 'relatedProductsSameBrand'));
    }



    public function getQuantity(Request $request)
    {
        $size = $request->size;
        $product_id = $request->product_id;

        $productItem = ProductItem::where('product_id', $product_id)
            ->where('size', $size)
            ->first();

        return response()->json($productItem->quantity);

    }

    public function notification()
    {
        return view('frontend.notification');
    }
}