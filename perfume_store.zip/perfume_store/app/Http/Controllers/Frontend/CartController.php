<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Product;

// model cart 
use App\Models\Cart;
use Illuminate\Support\Facades\Auth;

class CartController extends Controller
{
    public function cart()
    {
        $this->totalPrice();
        return view('frontend.cart');
    }

    public function add(Product $product, Request $request)
    {
        // $validated = $request->validate([
        //     'size' => 'required',
        //     'quantity' => 'required|numeric|min:1',
        // ]);
        // $size = $validated['size'];
        // $quantity = $validated['quantity'];
        // $cart = session('cart', []);

        // if(isset($cart[$product->id])){
        //     $cart[$product->id]['quantity'] += $quantity;

        // }
        // else{
        //     $cart[$product->id] = [
        //         'product_id' => $product->id,
        //         'image' => $product->images->first()->image,
        //         'name' => $product->name,
        //         'quantity' => $quantity,
        //         'size' => $validated['size'],
        //         'price'=> $product->price,
        //     ];
        // }
        // session()->put('cart', $cart);
        // $this->totalPrice();
        // return redirect()->back()->with('success', 'Thêm sản phẩm vào giỏ hàng thành công!');
        
        if (!(Auth::id())) {
            return view('frontend.login');
        }

        $validated = $request->validate([
            'size' => 'required',
            'quantity' => 'required|numeric|min:1',
        ]);

        $size = $validated['size'];
        $quantity = $validated['quantity'];
        $cart = session('cart', []);

        if (isset($cart[$product->id])) {
            $cart[$product->id]['quantity'] += $quantity;
            $cartItem = Cart::where('product_id', $product->id)
                ->where('user_id', Auth::id())->first();;
            $cartItem->quantity += $quantity;
            $cartItem->save();

        } else {
            $cart[$product->id] = [
                'product_id' => $product->id,
                'image' => $product->images->first()->image,
                'name' => $product->name,
                'quantity' => $quantity,
                'size' => $validated['size'],
                'price' => $product->price,
            ];
            // Tạo một bản ghi mới trong bảng cart
            $cartItem = new Cart();
            $cartItem->user_id = Auth::id();
            $cartItem->product_id = $product->id;
            $cartItem->quantity = $quantity;
            $cartItem->size = $size;
            $cartItem->save(); // Lưu vào cơ sở dữ liệu
        }
        session()->put('cart', $cart);

        $this->totalPrice();

        return redirect()->back()->with('success', 'Thêm sản phẩm vào giỏ hàng thành công!');

    }

    public function delete($product_id, $size){
        session()->pull('cart.'.$product_id);
        Cart::where('product_id', $product_id)->delete();
        $this->totalPrice();
        return back()->with('success', 'Xóa sản phẩm khỏi giỏ hàng thành công!');
    }

    protected function totalPrice(){
        $total_price = 0;
        foreach(session('cart') as $item){
            $total_price += $item['quantity'] * $item['price'];
        }
        session()->put('total_price', $total_price);
    }
}