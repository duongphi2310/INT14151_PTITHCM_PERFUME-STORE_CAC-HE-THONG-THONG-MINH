<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Order;

use Illuminate\Support\Facades\Auth;

class ListOrdersController extends Controller
{
    public function listOrders()
    {
        $userId = Auth::id(); // Lấy user_id của người mua đang đăng nhập
        $orders = Order::where('user_id', $userId)
            ->orderByDesc('id')
            ->paginate(5);
        return view('frontend.listorders', compact('orders'));
    }

    public function showDetailOrder(Order $order){
        return view('frontend.detailorder', compact('order'));
    }

    public function destroy(Order $order)
    {
        $order->delete();
        return redirect()->route('frontend.listorders')->with('success', 'Cancel successfully!');
    }
}